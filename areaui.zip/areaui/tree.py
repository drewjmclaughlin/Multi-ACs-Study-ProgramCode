# ----------------------------------------------------------------------------
# areaui
# Copyright (c) 2010, Charles Brandt
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# ----------------------------------------------------------------------------
"""
represent tree structures
(and the parts needed to represent trees)

*2010.03.01 18:55:16
Node is the parent class for AreaUI.area
"""
import os

class Node(object):
    """
    One level of a tree structure
    
    has a parent
    accept a list of items
    for each item
    if item is a string
    see if we already have it
    add it if we don't
    """
    def __init__(self, **kwargs):
        #the name of the node (for easier references)
        self.name = kwargs.get('name', '')

        #this is a more full representation of the node
        self.content = kwargs.get('content', None)
        #self.node = kwargs.get('node', None)

        #self.node.name should always equal self.name???

        #aka context
        self.parent = kwargs.get('parent', None)

        #aka children
        #could consider using sources.Items here instead...
        #is position needed? other customizations?
        #TODO:
        #Ordered Dictionaries showing up in standard in 3.1
        #should start using those
        #see also self.get

        #ideally, items should *always* contain other nodes
        #this keeps the interface consistent for navigating the tree
        #self.items = kwargs.get('items', [])
        self.items = []
        items = kwargs.get('items', [])
        for i in items:
            #make sure parents get set and batch is updated:
            self.add(i)


    def contains(self, item):
        """
        only matches if the item is a direct child of this node
        does not search the tree recursively...

        could consider something like a binary search tree
        if something like that is needed and efficiency matters. 
        """
        if item in self.items:
            return True
        else:
            return False

    def make_path(self):
        """
        even if we have a path, remake a new one
        return the path

        """
        if self.parent:
            return os.path.join(self.parent.make_path(), self.name)
        else:
            return os.path.join('./', self.name)

    def root(self):
        parent = self.parent
        if parent:
            while parent.parent:
                parent = parent.parent

            root = parent
        else:
            root = self
        return root

    def neighbors(self):
        """
        look at our parent's items
        return all but our self
        """
        if self.parent:
            #making a copy of the list, so we don't remove ourself there
            items = self.parent.items[:]
            items.remove(self)
            return items
        else:
            return []

    def get(self, name):
        """
        if we don't have a self.lookup dictionary
        generate it
        or update it
        then find the item with the sent name

        is it faster just to iterate over everything?
        how will we know when it is out of sync with the items in our list?
        if updating everytime, iterating over the list might be faster?
        """
        pass

    def add(self, item):
        """
        add item to self.items (or just self, if self is the list)
        """
        self.items.append(item)
        item.parent = self

    def remove(self, item):
        """
        item can be a string of the item's name that we want to remove
        or the item itself
        """
        if type(item) == type(''):
            #maybe we're only holding strings:
            #(though seems like we should always be holding nodes
            # maybe this won't ever happen):
            #if item in self.items:
            #    self.items.remove(item)
            #    return item
            #
            #else:
            for i in self.items:
                if i.name == item:
                    self.items.remove(i)
                    i.parent = None
                    return i
        else:
            self.items.remove(item)
            item.parent = None
            return item

    def delete(self, item=None, all=True):
        removed = self.clear()
        for r in removed:
            r.delete()
        del self

    def clear(self):
        """
        remove all items
        """
        #print len(self.items)
        
        #important to make a copy of the list
        #when operating on the contents of the list in the loop
        removed = []
        for item in self.items[:]:
            removed.append(self.remove(item))
        return removed
        #print len(self.items)

    
#aka Trunk(Branch):
class Root(Node):
    """
    special type of Node that has no parent
    """
    def __init__(self, **kwargs):
        Node.__init__(self, **kwargs)
        self.parent = None

