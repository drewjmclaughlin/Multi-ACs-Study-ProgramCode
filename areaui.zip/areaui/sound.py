"""
helpers for dealing with sound in pyglet

sometimes the built in Player has too much overhead

also a way to record

utilizing PyAudio wrapper of PortAudio
"""
import pyglet
import wave

try:
    import pyaudio
except:
    print """You must have pyaudio installed to record sounds.  PyAudio is available for download at:
    http://people.csail.mit.edu/hubert/pyaudio/"""
    #exit()


class Recorder(pyglet.event.EventDispatcher):
    """
    wraps pyaudio module to handle recording sounds under pyglet
    """
    def __init__(self, destination):
        #where to store the file on stop
        self.destination = destination
        self.recording = False
        self.length = None

        self.bits = pyaudio.paInt16
        self.channels = 1
        self.rate = 44100

        #larger chunk size = larger buffer = more time for program loop
        #to make it back to read it
        #try making a larger value if getting this error:
        #IOError: [Errno Input overflowed] -9981
        self.chunk = 2048
        self.interval = 1. / (self.rate / self.chunk)
        
        
    def start(self, length=None, destination=None):
        """
        check for existence of pyaudio module with try
        except: print where/how to install pyaudio

        if length is None, will record until self.recording is set to False
        by an external call

        if length is not None, will record for that length of time in seconds
        
        """
        if length:
            self.length = length

        if destination:
            self.destination = destination
            
        #time we've been recording for
        self.time = 0
        self.p = pyaudio.PyAudio()

        self.stream = self.p.open(format = self.bits,
                                  channels = self.channels,
                                  rate = self.rate,
                                  input = True,
                                  frames_per_buffer = self.chunk)

        print "* recording"
        self.all_chunks = []
        self.recording = True
        
        self.dispatch_events()
        self._update_schedule()

    def stop(self):
        print "* done recording"

        self.recording = False
        self._update_schedule()

        self.stream.close()
        self.p.terminate()

        print "* saving"

        # write data to WAVE file
        data = ''.join(self.all_chunks)
        wf = wave.open(self.destination, 'wb')
        wf.setnchannels(self.channels)
        wf.setsampwidth(self.p.get_sample_size(self.bits))
        wf.setframerate(self.rate)
        wf.writeframes(data)
        wf.close()
        print "* saved: %s" % self.destination

    def _update_schedule(self):
        pyglet.clock.unschedule(self.dispatch_events)
        if self.recording:
            interval = 1000.
            interval = min(interval, self.interval)
            pyglet.clock.schedule_interval_soft(self.dispatch_events, interval)

    def dispatch_events(self, dt=0):
        """Dispatch any pending events and perform regular heartbeat functions
        to maintain recording.

        :Parameters:
            `dt` : None
        """
        self.time += dt
        if self.length is not None:
            #print "time: %s" % self.time
            #print "length: %s" % self.length
            if self.time >= self.length:
                self.stop()
                
        if self.recording:
            data = self.stream.read(self.chunk)
            self.all_chunks.append(data)
            
class Player(pyglet.event.EventDispatcher):
    """
    wraps pyaudio module to handle playing sounds under pyglet
    """
    def __init__(self, source):
        self.source = source
        print "Creating new player with source: %s" % self.source
        
        self.playing = False
        self.data = ''
        
        self.length = None
        
        self.wf = None
        
        #larger chunk size = larger buffer = more time for program loop
        #to make it back to read it
        #try making a larger value if getting this error:
        #IOError: [Errno Input overflowed] -9981
        #
        #self.chunk = 1024
        self.chunk = 2048
        #self.chunk = 4096
        #self.chunk = 8192
        #*2011.11.06 16:38:07
        #or... if chunk is too large on linux, can get:
        #*** glibc detected *** python: malloc(): memory corruption: 0x0a2abdb8 ***
        #self.chunk = 16384

        #defaults... will be set by source
        self.bits = pyaudio.paInt16
        self.channels = 1
        self.rate = 44100

        if not self.source is None:
            self.load(self.source)

    def load(self, source):
        self.source = source
        if not (self.wf is None):
            self.wf.close()
        
        self.wf = wave.open(self.source, 'rb')

        self.p = pyaudio.PyAudio()
        self.bits = self.p.get_format_from_width(self.wf.getsampwidth())
        self.channels = self.wf.getnchannels()
        self.rate = self.wf.getframerate()
        
        self.interval = 1. / (self.rate / (self.chunk / (self.channels * 1.0) ) )
        self.interval = self.interval / 2.0
        #self.interval = self.interval / 16.0
        
        #print "Calculated interval: %s" % self.interval
        #print "1 / (%s (rate) / (%s (chunk) / %s (channels)))" % (self.rate, self.chunk, self.channels)
        
    def start(self, source=None):
        """
        play back sound using pyaudio
        """
        if not self.playing:
            self.playing = True
            if source:
                self.source = source

            #might load this twice (once on init, once here),
            #shouldn't hurt anythin though:
            self.load(self.source)
            #self.p = pyaudio.PyAudio()

            #time we've been playing for
            self.time = 0

            # open stream
            self.stream = self.p.open(format = self.bits,
                                      channels = self.channels,
                                      rate = self.rate,
                                      output = True,
                                      )
                                      #frames_per_buffer = self.chunk)


            self.data = self.wf.readframes(self.chunk)
            #print "first set of data read, dispatching events, then update"
            self.dispatch_events()
            #print "dispatched events"
            self._update_schedule()
            #print "updated schedule"
        else:
            print "already playing: %s" % self.source

    def stop(self):
        self.playing = False
        self._update_schedule()

        self.stream.close()
        self.p.terminate()

    def _update_schedule(self):
        pyglet.clock.unschedule(self.dispatch_events)
        if self.playing:
            interval = 1000.
            interval = min(interval, self.interval)
            #print "interval: %s" % interval
            #pyglet.clock.schedule_interval_soft(self.dispatch_events, interval)
            pyglet.clock.schedule_interval(self.dispatch_events, interval)

    def dispatch_events(self, dt=0):
        """Dispatch any pending events and perform regular heartbeat functions
        to maintain playing.

        :Parameters:
            `dt` : None
        """
        self.time += dt
        if self.length is not None:
            #print "time: %s" % self.time
            #print "length: %s" % self.length
            if self.time >= self.length:
                self.stop()
                
        if self.playing:
            # read data

            if self.data == '':
                self.stop()
            else:
                # play stream
                #print "writing data chunk to sound stream"
                self.stream.write(self.data)

            #print "reading next chunk"
            self.data = self.wf.readframes(self.chunk)
            
            #data = self.stream.read(self.chunk)
            #self.all_chunks.append(data)
            

