# ----------------------------------------------------------------------------
# areaui
# Copyright (c) 2010, Charles Brandt
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# ----------------------------------------------------------------------------
"""
*2010.01.21 17:28:57
AreaUI is a simple, system (language?) agnostic, way of specifying an user interface.

Points of interest are defined as Areas

all other specifications follow from that foundation.

"""
import pyglet
from pyglet.gl import *

from tree import Node

from content import Rectangle

class Area(Node):
    """
    outline is defined by a rectangle,
    but can contain other shapes and items

    Area does not do any of the actual drawing to batches
    just keeps track of the current batch in use

    Shapes and sub-areas can then call renders

    *2010.02.16 09:16:56 
    areas are like nodes in a tree

    items are an ordered list indicating stack (and render!) order
    for child nodes
    items can also be considered layers
    but they don't have to take up the whole area

    only items in the dynamic list will be automatically laid out
    they will completely ignore any items that are considered static... 
    that would get too complicated algorithmically...
    (although then shape will need to control how items are layed out )
    maybe dynamic really should be a subclass of area?)
    """
    def __init__(self, name=None, **kwargs):
        Node.__init__(self, name=name, **kwargs)

        if self.name is None:
            raise AttributeError, "Name must be supplied"

        #some redundancy here with rectangle
        #but since an area could contain a different primary shape
        #don't want to merge the two (inherit from one or the other)

        #only has meaning if this Area is inside of another Area
        self.x = kwargs.get('x', 0)
        self.y = kwargs.get('y', 0)

        #the position within the global window we're working in
        self.gx = self.x
        self.gy = self.y

        self.w = kwargs.get('w', 0)
        self.h = kwargs.get('h', 0)

        if not self.w:
            #can try to see if width was passed in instead
            #but 'w' should always take priority
            self.w = kwargs.get('width', 0)
        if not self.h:
            #can try to see if height was passed in instead
            #but 'h' should always take priority
            self.h = kwargs.get('height', 0)

        #APPEARANCE
        self.visible = kwargs.get('visible', True)
        #self.color = kwargs.get('color', (1, 1, 1, 1))
        #is clear a better default?
        #self.color = kwargs.get('color', (0, 0, 0, 0))
        #*2011.09.29 12:17:09 
        #or is black a better default?
        #clear doesn't always erase what was previously there
        self.color = kwargs.get('color', (0, 0, 0, 1))
        
        #Need to set up the batch before initializing the content:
        self.batch = kwargs.get('batch', pyglet.graphics.Batch())
        self.group = pyglet.graphics.OrderedGroup(0)

        # should be able to set it to a color or picture
        #self.background = kwargs.get('background', None)

        #should be an object used for determining clicks
        #e.g. visible content
        #Rectangle.__init__(self, **kwargs)
        #this should also be the object responsible for
        #rendering this area's content to the batch
        #(not responsible for rendering sub items (self.items)
        # to the batch though)

        #this is not a kwarg, since most other types of Content will
        #want to wait until the area has been created
        #before the content object is created / defined.
        #at that point can assign the area content to the new content item
        self.content = Rectangle(self)

        # BEHAVIOR

        #maybe each of these should be settable
        #clickable, dragable, resizable, droppable
        #self.properties = []
        self.clickable = kwargs.get('clickable', False)
        self.down = False

        #remember that the first draggable object encountered
        #in an area hierarchy will take precedence in the drag action
        #(children will not display their draggable nature)
        self.draggable = kwargs.get('draggable', False)
        #what has been dropped on us
        self.holding = None
        
        #rather than a boolean value, pass in the list of items
        #that should be checked for being dropped
        #self.droppable = kwargs.get('droppable', False)
        self.droppables = kwargs.get('droppables', None)
        
        self.rotateable = kwargs.get('rotateable', False)

        #root is a method on area that looks up the root:
        #root areas should not have any parents.
        #self.root = kwargs.get('root', False)

        self.action = kwargs.get('action', self.default_action)

        self.selected = False

        # IDEAS
        #(might not be needed)

        #if items are passed in with relative x, y coordinates
        #can assume that they will not be affected by our layout parameter?
        #self.static = []
        #self.dynamic = []

        #in the case of a scrollable item
        #the visual content may be different than the hidden content
        #would need to know hidden shape for calculating scrollbars
        #
        #(should also look at pyglet.Text.scrollable to see how they
        # render only the partially visible part)
        #self.content_shape = Rectangle(self.x, self.y, self.w, self.h)

        #where the 0,0 point of the coordinate system for this area is
        #do we *ever* need to change this? or is the align
        #valid options: lower_left, uppper_left, lower_right, upper_right 
        #self.zero = kwargs.get('zero', ('bottom', 'left'))

        # LAYOUT RELATED:

        #rendered outside of the background
        #border is border_width
        #might be better to keep this with ninepatch concept
        self.border = kwargs.get('border', 0)
        #self.border_color = None

        #number of pixels to pad between objects?
        #will not affect how the background is rendered
        self.padding = kwargs.get('padding', 0)
        
        #how items should be arranged
        #default currently top, left
        #can have more than one item for (bottom, top), (left, right)
        # center is the middle for both
        self.align = kwargs.get('align', ('top', 'left'))

        #describes the way the items will be arranged in the area.
        #layout can be either:
        # flow, column, row, manual
        self.layout = kwargs.get('layout', 'flow')

        #resize allows the actual area dimensions to change proportions
        #this allows an area to grow to accomodate its items
        self.resizable = kwargs.get('resizable', True)

        self.max_w = kwargs.get('max_w', None)
        self.max_h = kwargs.get('max_h', None)
        
        #making scrollable a subclass of Area
        #should not be both scalable and scrollable:
        self.scalable = kwargs.get('scalable', False)

        #only applies when automatically arranging items..
        #might be some times that it's ok to have items overlap
        self.overlap = kwargs.get('overlap', False)
        
        #constrain the normal flow behavior of items to be in either a
        #column or row only (single_column?)
        #self.fixed_column = kwargs.get('fixed_column', False)
        #self.fixed_row = kwargs.get('fixed_row', False)

    def resize(self, max_w, max_h):
        #TODO:
        #check if we are allowed to be resized, scaled, fit, etc
        #raise an error if not
        ratio_w, ratio_h = 0, 0
        if self.w > max_w:
            ratio_w = 1.0 * self.w / max_w
            #print " %s == %s " % (int(self.w / ratio_w), max_w)
            #assert int(self.w / ratio_w) == max_w

            #self.w = max_w
            #self.h = 1.0 * self.h / ratio

        if self.h > max_h:
            ratio_h = 1.0 * self.h / max_h
            #print " %s == %s " % (int(self.h / ratio_h), max_h)
            #assert int(self.h / ratio_h) == max_h

            #self.h = max_h
            #self.w = 1.0 * self.w / ratio

        scale = 0
        if ratio_w or ratio_h:
            if ratio_w > ratio_h:
                scale = 1.0 / ratio_w
            else:
                scale = 1.0 / ratio_h
        else:
            #don't need to scale
            pass

        if scale:
            self.content.scale(scale)
            
        #print "scale: %s resulted in: %s w, %s h" % (scale, self.w, self.h)
        #self.content.update()
        self.w = self.content.w
        self.h = self.content.h

        if not self.w or not self.h:
            print "WARNING: resize resulted in a zero dimension (%s)" % self.name
            print "scale: %s resulted in: %s w, %s h" % (scale, self.w, self.h)

    

    #aka update_layout
    def rearrange(self, keep_dimensions=False, **kwargs):
        """
        go through all of our items

        assume sizes are set by here?

        depending on our layout
        arrange the items (by setting their relative x and y positions)
        accordingly
        """
        cur_row_num = 1
        total_h = 0
        total_w = 0
        rows = []

        self.max_w = kwargs.get('max_w', None)
        self.max_h = kwargs.get('max_h', None)

        #if self.max_w or self.max_h:
        #    print "%s using passed in maxes: %s, %s" % (self.name, self.max_w, self.max_h)

        if (not self.w or not self.h) and self.content:
            #try setting our dimensions from the content
            self.content.update()
            self.w = self.content.w
            self.h = self.content.h
            #print "%s dimensions updated: %s, %s" % (self.name, self.w, self.h)

        #FIND OUR MAXES
        if self.parent and not keep_dimensions:
            #print "Using parent: %s" % self.parent.name
            if self.parent.w and not self.max_w:
                self.max_w = self.parent.w
                
            ##     print "updated max w for %s: %s" % (self.name, self.max_w)
            ## elif not self.max_w:
            ##     print "%s parent (%s) has no w %s" % (self.name, self.parent.name, self.parent.w)
            ## else:
            ##     print "%s max_w already set: %s" % (self.name, self.max_w)

            if self.parent.h and not self.max_h:
                self.max_h = self.parent.h
                
            ##     print "updated max h for %s: %s" % (self.name, self.max_h)
            ## elif not self.max_h:
            ##     print "%s parent (%s) has no h %s" % (self.name, self.parent.name, self.parent.h)
            ## else:
            ##     print "%s max_h already set: %s" % (self.name, self.max_h)
            
        ## else:
        ##     print "%s: no parent assigned: %s" % (self.name, self.parent)

        elif keep_dimensions:
            if not self.max_w and self.w:
                self.max_w = self.w
            if not self.max_h and self.h:
                self.max_h = self.h

        #account for border:
        if self.border:
            if self.max_w:
                self.max_w = self.max_w - (2 * self.border)
            if self.max_h:
                self.max_h = self.max_h - (2 * self.border)
                

        #now that we've done that... have we outgrown our space?
        if self.max_w and self.max_h:
            if ((self.w - 2*self.border > self.max_w) or (self.h - 2*self.border > self.max_h)):
                self.resize(self.max_w, self.max_h)
        ##     else:
        ##         print "%s: max exists %s,%s less than max %s,%s" % (self.name, self.w, self.h, self.max_w, self.max_h)
        ##         pass

        ## else:
        ##     print "%s: no maxes exist: %s,%s" % (self.name, self.max_w, self.max_h)
            
            
        #print "%s max_w: %s, max_h: %s" % (self.name, self.max_w, self.max_h)


        #create temporary areas to hold rows
        #so that we can apply the correct alignments after we know dimensions
        row_name = "row%04d" % cur_row_num
        cur_row = Area(row_name)


        #the following illustrates a flow, row, and column layout
        #other layouts are certainly possible, but should be performed separate
        for item in self.items:
            if not item.w or not item.h:
                item.rearrange(max_w=self.max_w, max_h=self.max_h)
            #else:
            #    item.rearrange(max_w=self.max_w, max_h=self.max_h, keep_dimensions=True)
                
                #print "dimensions of %s: %s, %s" % (item.name, item.w, item.h)
                
            #handle resizing
            if self.max_w and item.w > self.max_w:
                #could check if item is resizable, and request a resize
                #to our maximum size
                print "Item '%s' width (%s) is bigger than %s max width (%s)" % (item.name, item.w, self.name, self.max_w)
                if item.resizable:
                    item.resize(self.max_w, self.max_h)
            if self.max_h and item.h > self.max_h:
                #could check if item is resizable, and request a resize
                #to our maximum size
                print "Item '%s' height (%s) is bigger than %s max height (%s)" % (item.name, item.h, self.name, self.max_h)
                if item.resizable:
                    item.resize(self.max_w, self.max_h)

                    
            #print "placing item %s: %s, %s" % (item.name, item.w, item.h)
            if (self.max_w and (item.w + cur_row.w > self.max_w)) or self.layout == "column":
                #time to start a new row, this item goes over the max:

                #however, if we're supposed to be a row, something is wrong:
                if self.layout == "row":
                    print "%s items in %s exceed max width (%s)" % (len(self.items), self.name, self.max_w)

                total_h += cur_row.h
                total_h += self.padding
                #don't want the very last padding added
                cur_row.w -= self.padding
                if cur_row.w > total_w:
                    total_w = cur_row.w
                rows.append(cur_row)

                #print "Starting new row"
                cur_row_num += 1
                #save the old
                #make the new
                row_name = "row%04d" % cur_row_num
                cur_row = Area(row_name)
                cur_row.w = item.w
                cur_row.w += self.padding
                cur_row.h = item.h
                cur_row.items.append(item)
            else:
                #must fit in the current row
                cur_row.w += item.w
                cur_row.w += self.padding
                if cur_row.h < item.h:
                    cur_row.h = item.h
                cur_row.items.append(item)

        #get the last row
        if len(cur_row.items):
            total_h += cur_row.h
            #don't want the very last padding added
            cur_row.w -= self.padding
            if cur_row.w > total_w:
                total_w = cur_row.w
            cur_row_num += 1
            rows.append(cur_row)

        #root nodes of trees should only be set manually
        if self.name != 'root' and not keep_dimensions:
            #in the case of no items (only our own content)
            #then total_h and total_w will be 0
            #print "Updating dimensions for: %s" % (self.name)
            if total_h > self.h:
                #print "Height updated from: %s to %s" % (self.h, total_h)
                self.h = total_h + (2 * self.border)
            #else:
            #    print "Keeping height of %s instead of %s" % (self.h, total_h)
                
            if total_w > self.w:
                #print "Width updated from: %s to %s" % (self.w, total_w)
                self.w = total_w + (2 * self.border)
            #else:
            #    print "Keeping width of %s instead of %s" % (self.w, total_w)
        #else:
        #    print "Keeping original dimensions: %s: %s, %s" % (self.name, self.w, self.h)

        #print rows
        #now we've collected our rows internally
        #apply the correct alignment by updating relative coordinates:
        if self.align[0] == 'top':
            cur_y = total_h - self.border
        elif self.align[0] == 'bottom':
            cur_y = total_h + self.border
        else:
            cur_y = total_h

        offset = self.h - total_h
        #if self.align == ('bottom', 'right'):
        #print "%s has %s rows" % (self.name, len(rows))
        for row in rows:
            cur_y = cur_y - row.h
            self.realign(cur_y, row.w, row.h, row.items, offset)
            cur_y = cur_y - self.padding
            
        self.update_layout()


    def realign(self, cur_y=0, width=None, height=None, items=None, offset=0):
        """
        assumes all items are in a row
        """
        if items is None:
            items = self.items
        if not width:
            width = self.w
        if not height:
            height = self.h
            
        #for when total_h is less than container height
        #offset = self.h - outer_h

        #cur_x = 0
        cur_x = 0 + self.border
        #cur_y = outer_h - height
        for item in items:
            #print "(%s) cur_x: %s, width: %s, item_w: %s, cur_y: %s, height: %s, item_h: %s" % (self.name, cur_x, width, item.w, cur_y, height, item.h)
            #print "y before realign: %s" % item.y
            if self.align[0] == 'top':
                item.y = cur_y + (height - item.h) + offset
            elif self.align[0] == 'bottom':
                item.y = cur_y #+ self.padding
            elif self.align[0] == 'center':
                #print "cur_y: %s, height: %s, item_h: %s, offset: %s" % (
                #    cur_y, height, item.h, offset)
                item.y = cur_y + ((height - item.h) / 2) + (offset / 2) #+ self.padding
            #print "y after realign: %s" % item.y

            #print "x before realign: %s" % item.x
            if self.align[1] == 'left':
                item.x = cur_x
            elif self.align[1] == 'right':
                item.x = cur_x + ( self.w - width - (self.border * 2) )
            elif self.align[1] == 'center':
                item.x = cur_x + ( self.w - width - (self.border * 2) ) / 2 

            #print "x after realign: %s" % item.x
                
            cur_x += item.w
            cur_x += self.padding
            
    ## def get_size(self):
    ##     """
    ##     return the width and heights allowable for this area

    ##     will depend on the layout property
    ##     """
    ##     #root case
    ##     if not self.items:
    ##         #the current width and height of this area must be all there is
    ##         #should have been set by content, or initialized
    ##         if not self.w or not self.h and self.content:
    ##             #try setting our dimensions from the content
    ##             self.content.update()
    ##         if not self.w or not self.h:
    ##             print "Not enough information known about this area:"
    ##             print "%s: %s w, %s h" % (self.name, self.w, self.h)
    ##             exit()
    ##         else:
    ##             return (self.w, self.h)

    def default_action(self, gx=0, gy=0, button=None, modifiers=None):
        print self.name

    def on_key_press(self, symbol, modifiers):
        #print "KEY PRESS: %s" % self.name
        for item in self.items:
            item.on_key_press(symbol, modifiers)

    def on_text(self, text):
        for item in self.items:
            item.on_text(text)

    def on_text_motion(self, motion, select=False):
        for item in self.items:
            item.on_text_motion(motion, select)
        

    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        for item in self.items:
            item.on_mouse_scroll(x, y, scroll_x, scroll_y)

    def has_point(self, gx, gy):
        return self.content.has_point(gx, gy)

    def action_call(self, gx, gy, button, modifiers):
        """
        usually when we pass in an action, we don't need to know the coordinates
        we just want the action called
        when the event happens

        if your action needs the mouse coordinates, buttons, and modifiers,
        over ride this call in your subclass of Area
        """
        self.action()

    def on_mouse_press(self, gx, gy, button, modifiers):
        #print "%s received %s, %s, contains? %s" % (self.name, gx, gy, self.has_point(gx, gy))
        if self.has_point(gx, gy):
            if self.clickable or self.draggable:
                #might be many cases where we need to know if it was pressed
                self.down = True

            if self.clickable:
                #self.content.color = (.78, .78, .78, 1)
                
                #self.action(gx, gy, button, modifiers)
                self.action_call(gx, gy, button, modifiers)
                #print "Hello"

            ## #if we're not handling the event, but it's in our area
            ## #see if anyone else wants to know about it:
            ## if not (self.clickable or self.draggable):
                
            #reordering items should affect rendering
            #(most recenly clicked should show up first)
            #if self.items and self.items[-1].has_point(gx, gy):
            #    return self.items[-1].on_mouse_press(gx, gy, button, modifiers)

            #want to go in reverse when checking for clicks...
            #item added last is drawn last (shows up on top)
            #which should mean it is clicked first:
            #for i in self.items:
            for i in range(len(self.items)-1, -1, -1):
                item = self.items[i]
                if item.has_point(gx, gy):
                    if item.clickable:
                        self.items.remove(item)
                        self.items.append(item)
                        #self.items.insert(0, i)

                        #if a new batch is created, need to re-render()
                        #and render needs to clear old items
                        #self.update_batch(pyglet.graphics.Batch(), self._group)
                        #self.update_batch(pyglet.graphics.Batch(), self.group)
                        #self.update_batch(self.batch, self.group)
                        self.update_layout()

                    return item.on_mouse_press(gx, gy, button, modifiers)
    
    def on_mouse_release(self, gx, gy, button, modifiers):
        #not concerned about a hit by now...
        #sometimes the mouse moves beyond the area.

        #print "%s release called. Down? %s" % (self.name, self.down)
        
        #only need to do all of these checks if we were previously being held
        if self.down:
            self.down = False

            if self.droppables:
                if self.dropped_on and not self.dropped_on.content.contains(self):
                    self.dropped_on.holding = None
                    self.dropped_on = None
                    
                #should see if we were dropped on any of our droppables
                for d in self.droppables:
                    if d.holding == None and d.content.contains(self):
                        #this is a new drop.
                        #perform any specialized drop actions
                        self.dropped(d)
                    
                    #be sure to clear/free up any prior locations
                    if d.holding == self:
                        d.holding = None

                    #associate self with drop, realign
                    #make sure d is empty (only allowing one item)
                    if d.holding == None and d.content.contains(self):
                        #print "%s contains %s" % (d.name, self.name)
                        self.dropped_on = d
                        d.holding = self
                        
                        #align d to self.
                        #cannot use rearrange for this
                        #d is not one of our items.

                        #align to lower left:
                        self.x = (d.gx - self.gx) + self.x
                        #then move  to center:
                        self.x += (d.w - self.w) / 2

                        self.y = (d.gy - self.gy) + self.y
                        self.y += (d.h - self.h) / 2

                        self.update_layout()

                        #print "%s contains %s" % (d.name, self.name)
                        
        #make sure to release all of our items...
        #need to do this whether we are down or not!
        for i in self.items:
            i.on_mouse_release(gx, gy, button, modifiers)

        
    def on_mouse_drag(self, gx, gy, dx, dy, button, modifiers):
        #if it has already been clicked, we still want to drag it
        #in case the mouse is too fast for the position update
        if self.draggable and self.down:
            new_x = self.x + dx
            new_y = self.y + dy

            if new_x < 0:
                new_x = 0
            if new_y < 0:
                new_y = 0
            #make sure we're within the bounds of our parent if we have one
            #(if no parent, probably shouldn't be draggable... 
            # no way to know the boundaries)
            if self.parent:
                if new_x + self.w > self.parent.x + self.parent.w:
                    new_x = self.parent.x + self.parent.w - self.w 
                if new_y + self.h > self.parent.y + self.parent.h:
                    new_y = self.parent.y + self.parent.h - self.h 

            self.x = new_x
            self.y = new_y
            #self.debug()
            self.update_global_coords()
            #for i in self.items:
            #    i.update_global_coords()

        else:
            #if we didn't drag ourselves, make sure none of our items
            #need to be dragged
            for i in self.items:
                i.on_mouse_drag(gx, gy, dx, dy, button, modifiers)

    def on_mouse_motion(self, gx, gy, dx, dy):
        """
        not to be confused with on_mouse_drag
        """
        if self.has_point(gx, gy):
            for i in self.items:
                if i.has_point(gx, gy):
                    self.items.remove(i)
                    self.items.insert(0, i)
                    i.on_mouse_motion(gx, gy, dx, dy)
                    return
                
    def dropped(self, item):
        """
        accept the Area item that was dropped on this area
        and do something with it
        """
        print "%s detected %s" % (self.name, item.name)
        
    def add(self, item):
        Node.add(self, item)
        #assign our batch to the item and its subitems
        self.update_batch(self.batch, self.group)
        self.update_global_coords()

    def remove(self, item):
        actual = Node.remove(self, item)
        
        #self.update_batch(self.batch, self.group)
        #self.update_global_coords()

        #regenerate layout (new batch)
        #self.update_layout()

    def remove_self(self):
        if self.parent:
            self.parent.remove(self)
        del self

    def clear(self):
        """
        remove all items
        """
        removed = Node.clear(self)
        self.update_layout()
        #for item in self.items:
        #    self.remove(item)

        #incase you want to removed them from memory
        #or save them for later
        return removed

    def update_global_coords(self):
        """
        right now this only happens:
             after an item has been dragged to a new location

        but will probably need to be called when arranging items automatically
        """
        if self.parent:
            # *2010.03.05 11:52:56
            # this doesn't seem to catch the case when the parent's
            # global coordinates are correct
            # but the child's are not
            # commenting the whole block out
            # if this is called, let's update everything!
            # if it doesn't need to be called, check can happen
            # outside of here
            #print "%s has parent" % self.name
            #check if we've moved first
            #on a drag, we've already updated these?
##             if ((self.gx != self.parent.gx + self.x) or
##                 (self.gy != self.parent.gy + self.y)):
            self.gx, self.gy = self.parent.gx + self.x, self.parent.gy + self.y
            for i in self.items:
                i.update_global_coords()
            #else:
            #    print "Globals already set"

        #must be a root area. if update_globals was called,
        #must need to update all items too..
        else:
            self.gx, self.gy = self.x, self.y
            for i in self.items:
                i.update_global_coords()

        #duplicate version... does the same thing:
        
        ## if self.parent:
        ##     if self.x + self.parent.gx != self.gx:
        ##         self.gx = self.x + self.parent.gx
        ##     if self.y + self.parent.gy != self.gy:
        ##         self.gy = self.y + self.parent.gy
        ## else:
        ##     self.gx = self.x
        ##     self.gy = self.y            
        ## for i in self.items:
        ##     i.update_layout()

    def update_layout(self):
        """
        when the order of things changes,
        when items are removed,
        can call this to rebuild the layout

        if re-creating the batch from scratch:
        need to find the root object and call render for it and all items in it
        with a new batch
        (otherwise the new batch won't be drawn)

        could also consider a dirty flag
        which is caught at draw
        and update_layout is called from root area

        could also consider if it is possible to use groups to achieve the
        same effect
        
        not to be confused with:
        update_global_coords()
        """

        original = self.batch

        root = self.root()
            
        #make a new batch
        root.batch = pyglet.graphics.Batch()
        root.group = pyglet.graphics.OrderedGroup(0)
        
        root.update_batch(root.batch, root.group)
        root.update_global_coords()        
        #then re-render
        root.render()

        # clean up the original batch memory:
        # is this enough?
        del original

        
    def update_batch(self, batch, group):
        """
        typically after an item is added
        we want to update the batch for it
        and all sub_items
        """
        self.batch, self.group = batch, group
        
        #seems to improve order preservation of items 
        count = 0
        for i in self.items:
            order = pyglet.graphics.OrderedGroup(count, self.group)
            i.update_batch(batch, order)
            count += 1

            
    def render(self):
        """
        draw ourself to the batch first
        then draw all of our other items to the batch after that
        """
        if self.visible and self.content:
            self.content.update()

        for i in self.items:
            i.render()

    def draw(self):
        #self.update_global_coords()
        #self.update_elements()
        #self.update_layout()
        self.render()

        glPushAttrib(GL_ENABLE_BIT)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        self.batch.draw()
        
        glPopAttrib()

    def d_helper(self, level):
        indent = "  "
        tab = indent*level
        if self.parent:
            pn = self.parent.name
        else:
            pn = ""

        if self.holding:
            hn = self.holding.name
        else:
            hn = ""
            
        print "%s%s: %sgx %sgy %sx %sy %sw %sh; parent:%s; holds:%s; colr:%s" % (tab, self.name, self.gx, self.gy, self.x, self.y, self.w, self.h, pn, hn, self.color)
        for i in self.items:
            i.d_helper(level+1)

    def debug(self, root=False):
        """
        sometimes it can be difficult to know
        if settings in the area are getting updated,
        or if settings in the batch are getting updated.

        this prints what is going on in the area

        recursively call d_helper for all items in our tree

        if root is true, go to the top and start there
        """
        
        parent = self.parent
        if root and parent:
            while parent.parent:
                parent = parent.parent

            cur_root = parent
        else:
            cur_root = self

        cur_root.d_helper(0)
            

class RootArea(Area):
    """
    Special Area that cannot belong to another area
    if a window is sent
    locks to the size of the window

    if using text inputs, Root Area must be the root Area
    """
    def __init__(self, window=None, **kwargs):
        ## if not kwargs.has_key('name'):
        ##     kwargs['name'] = 'root'
        ##     print "root added to kwargs"
        ## else:
        ##     print kwargs.get('name')
        Area.__init__(self, name='root', **kwargs)

        #place to store what TextInput areas currently have focus:
        self.focus = []

        #redundant, but should always be this:
        self.x = 0
        self.y = 0
        self.gx = 0
        self.gy = 0

        #in case we need to access any properties of it later
        self.window = window
        if window is None and (not self.w or not self.h):
            print "Warning, no size"
        elif window:
            self.w = window.width
            self.h = window.height
            self.max_w = self.w
            self.max_h = self.h
            
        #usually don't have content here:
        #self.visible = False

    def clear(self):
        """
        special case for RootArea, want to make sure all focuses are unset
        """
        Area.clear(self)
        self.focus = []

    def on_resize(self, width, height):
        if self.window:
            self.w = width
            self.h = height

    def on_mouse_press(self, x, y, button, modifiers):
        if len(self.focus) > 0:
            result = self.focus[-1].on_mouse_press(x, y, button, modifiers)
            if result == pyglet.event.EVENT_HANDLED:
                return result
        return Area.on_mouse_press(self, x, y, button, modifiers)

    def on_mouse_drag(self, x, y, dx, dy, button, modifiers):
        if len(self.focus) > 0:
            return self.focus[-1].on_mouse_drag(x, y, dx, dy, button, modifiers)
        return Area.on_mouse_drag(self, x, y, dx, dy, button, modifiers)

    def on_mouse_release(self, x, y, button, modifiers):
        if len(self.focus) > 0:
            return self.focus[-1].on_mouse_release(x, y, button, modifiers)
        return Area.on_mouse_release(self, x, y, button, modifiers)

    def on_key_press(self, symbol, modifiers):
        if len(self.focus) > 0:
            return self.focus[-1].on_key_press(symbol, modifiers)
        return Area.on_key_press(self, symbol, modifiers)

    def on_text(self, text):
        if len(self.focus) > 0:
            return self.focus[-1].on_text(text)
        return Area.on_text(self, text)

    ## def render(self):
    ##     """
    ##     draw ourself to the batch first
    ##     then draw all of our other items to the batch after that
    ##     """
    ##     Area.render(self)

    def event_stack(self):
        """
        show the event stack of the current EventDispatcher object
        pyglet.window.Window is an EventDispatcher.
        """
        print "%s items. %s" % (len(self.window._event_stack), self.name)
        print self.window._event_stack
        #print self.layout

        
