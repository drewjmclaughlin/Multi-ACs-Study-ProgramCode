# ----------------------------------------------------------------------------
# areaui
# Copyright (c) 2010, Charles Brandt
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# ----------------------------------------------------------------------------
import pyglet
from area import Area, RootArea
from content import Text, Image, Animation, Input, FlatContent

import os, codecs, datetime, sys

class Scrollable(Area):
    """
    incomplete
    """
    def __init__(self, name, **kwargs):
        Area.__init__(self, name, **kwargs)
        #scrollable introduces a new concept... a hidden part of the area
        #almost as if there are two areas in one...
        #might be good to conceptualize it that way
        #also look at TextLayouts
        #so that we're not taking up memory by rendering items not visible
        self.scrollable = kwargs.get('scrollable', True)
        #should not scale something that is scrollable
        self.scalable = False

        #room for a scroll bar...
        #todo: consider bottom gutter?
        #self.gutter = kwargs.get('gutter', 0)

class TextInput(Area):
    """
    for TextInput it's important to initialize the width (w) for the area
    otherwise there is no initial size, or the text changes size on input

    height is determined automatically based on the font size

    if a larger area height is desired, this also makes it easy to align a
    TextInput within another Area
    """
    def __init__(self, name, w, h=None, color=None, **kwargs):
        Area.__init__(self, name, w=w, **kwargs)
        input_args = kwargs.get('input_args', {})
        if color:
            input_args['color'] = color
        input_args['align'] = 'left'
        text = kwargs.get('text', name)
        self.content = Input(self, text, h, **input_args)
        self._focused = False

    def _get_text(self):
            return self.content.text
    def _set_text(self, text):
            self.content.text = text
    text = property(_get_text, _set_text)

    def set_focus(self, x=0, y=0, button=None, modifiers=None):
        self._focused = True

        root = self.root()

        ## self.debug()        
        ## print ""
        ## print "=============="
        ## print ""
        ## root.debug()
        ## print dir(root)
        ## print "Root type: %s" % type(root)

        
        root.focus.append(self)
        self.content.caret.visible = True
        self.content.caret.on_mouse_press(x, y, button, modifiers)

    def unset_focus(self, x=0, y=0, button=None, modifiers=None):
        """
        this is what you want unless you want to remove everything from
        a RootArea with .clear()... can't reuse items in that case
        """
        #if we're not focused, don't want to try to pop from an empty list
        if self._focused:
            self.content.caret.visible = False
            self.root().focus.pop()
            self._focused = False

    def select_all(self):
        self.set_focus()

        self.content.caret.mark = 0
        self.content.caret.position = len(self.content.document.text)
        
        #self.content.caret.move_to_point(0, 0)
        #self.content.caret.select_to_point(self.w, 0)
        
    def on_mouse_press(self, x, y, button, modifiers):
        #self.root().debug()
        if button == pyglet.window.mouse.LEFT and self.has_point(x, y) and not self._focused:
            self.set_focus(x, y, button, modifiers)
            return pyglet.event.EVENT_HANDLED
        if button == pyglet.window.mouse.LEFT and self._focused:
            if self.has_point(x, y):
                self.content.caret.on_mouse_press(x, y, button, modifiers)
                return pyglet.event.EVENT_HANDLED
            else:
                self.unset_focus(x, y, button, modifiers)
                #if self.action:
                #    self.action(x, y, button, modifiers)
                return pyglet.event.EVENT_UNHANDLED

        Area.on_mouse_press(self, x, y, button, modifiers)
        return pyglet.event.EVENT_UNHANDLED

    def on_mouse_drag(self, x, y, dx, dy, button, modifiers):
        if self._focused:
            self.content.caret.on_mouse_drag(x, y, dx, dy, button, modifiers)
            return pyglet.event.EVENT_HANDLED

        Area.on_mouse_drag(self, x, y, dx, dy, button, modifiers)
        return pyglet.event.EVENT_UNHANDLED

    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        if self._focused:
            self.content.caret.on_mouse_scroll(x, y, scroll_x, scroll_y)
            return pyglet.event.EVENT_HANDLED

        Area.on_mouse_scroll(self, x, y, scroll_x, scroll_y)
        return pyglet.event.EVENT_UNHANDLED

    def on_key_press(self, symbol, modifiers):
        from pyglet.window import key

        #I think the aim behind this is to cycle between different
        #inputs if more than one is on the screen
        #that doesn't happen often
        #and I'm not sure that this works even if it does happen
        #
        #there may be some cases where it is good to get rid of any
        #"ENTER" characters (single line text inputs)
        #but that should be in a configuration, not here.
        ## if self._focused and symbol in (key.ENTER, key.TAB):
        ##     self.content.caret.visible = False
        ##     self.root().focus.pop()
        ##     self._focused = False
        ##     #if self.action:
        ##     #    self.action(self)
        ##     return pyglet.event.EVENT_HANDLED

        Area.on_key_press(self, symbol, modifiers)
        return pyglet.event.EVENT_UNHANDLED

    def on_text(self, text):
        if self._focused:
            #print text
            self.content.caret.on_text(text)
            #print self.content.document.text
            return pyglet.event.EVENT_HANDLED

        Area.on_text(self, text)
        return pyglet.event.EVENT_UNHANDLED

    def on_text_motion(self, motion, select=False):
        #print "Motion detected: %s" % motion
        if self._focused:
            self.content.caret.on_text_motion(motion, select)
            return pyglet.event.EVENT_HANDLED

        Area.on_text_motion(self, motion, select)
        return pyglet.event.EVENT_UNHANDLED

class SingleLineTextInput(TextInput):
    def __init__(self, name, w, h=None, color=None, action=None, **kwargs):
        TextInput.__init__(self, name, w=w, h=h, color=color, **kwargs)
        self.action = action
        
    def on_key_press(self, symbol, modifiers):
        from pyglet.window import key

        if self._focused and symbol in (key.ENTER, key.TAB):
            if self.action:
                self.content.caret.visible = False
                self.root().focus.pop()
                self._focused = False
                self.action(self)
            return pyglet.event.EVENT_HANDLED
    
    def on_text(self, text):
        if self._focused:
            if ord(text) != 13:
                #print "->%s<-" % ord(text)
                self.content.caret.on_text(text)
            #print self.content.document.text
            return pyglet.event.EVENT_HANDLED

        else:
            Area.on_text(self, text)
            return pyglet.event.EVENT_UNHANDLED
            
class ImageArea(Area):
    """
    Example of assigning other types of content to an Area
    it is fine to do this outside of an object,
    just be sure to get the order right:
    1. create the area
    2. create the content with the new area
    3. assign the content to the area
    """
    def __init__(self, image_path, **kwargs):
        #using image_path as the name of the Area
        Area.__init__(self, image_path, **kwargs)
        image_args = kwargs.get('image_args', {})
        content = Image(self, image_path, **image_args)
        self.content = content
        self.rearrange()

        # could combine 2 & 3:
        #self.content = Text(name, **kwargs)

class AnimationArea(Area):
    """
    area that holds an Animation content item
    """
    def __init__(self, name, images, **kwargs):
        Area.__init__(self, name, **kwargs)
        image_args = kwargs.get('image_args', {})
        self.content = Animation(self, images, **image_args)
        self.rearrange()

        # could combine 2 & 3:
        #self.content = Text(name, **kwargs)

class TextArea(Area):
    """
    Example of assigning other types of content to an Area
    it is fine to do this outside of an object,
    just be sure to get the order right:
    1. create the area
    2. create the content with the new area
    3. assign the content to the area
    """
    def __init__(self, name, **kwargs):
        Area.__init__(self, name, **kwargs)
        text_args = kwargs.get('text_args', {'color':(0,0,0,255), 'font_size':20})
        #text_args = kwargs.get('text_args', {'color':(0,0,0,255)})
        #text_args = kwargs.get('text_args', {})
        content = Text(self, name, **text_args)
        self.content = content
        self.rearrange()

        # could combine 2 & 3:
        #self.content = Text(name, **kwargs)

class Button(Area):
    """
    Although a button is just a clicable Area,
    for consistencey we can assume some dimensions 

    Also, if a theme is later applied, this would make that easier.
    """
    def __init__(self, name, **kwargs):
        #initialize area first
        Area.__init__(self, name, **kwargs)

        #now set some default sizes if none have been set:
        self.w = kwargs.get('w', 50)
        self.h = kwargs.get('h', 15)

        self.align = ('center', 'center')

        self.clickable = True
        self.color = kwargs.get('color', (.5,.5,.5,1))

        self.border = 5
        
        text_args = kwargs.get('text_args', {'color':(0,0,0,255), 'font_size':24})
        t1 = TextArea(self.name, text_args=text_args)
        self.add(t1)

        #by keeping our default content as a Rectangle,
        #buttons have a background... don't want to override that with Text
        #text_args = kwargs.get('text_args', {})
        #content = Text(self, name, **text_args)
        #self.content = content

        self.rearrange()

class CenteredButton(Area):
    """
    center the text in the area using rearrange
    """
    def __init__(self, name, **kwargs):
        #initialize area first
        Area.__init__(self, name, **kwargs)

        #now set some default sizes if none have been set:
        self.w = kwargs.get('w', 50)
        self.h = kwargs.get('h', 15)

        #self.clickable = True
        self.color = kwargs.get('color', (1,0,0,1))

        self.default_color = self.color

        text_args = kwargs.get('text_args', {'color':(0,0,0,255), 'font_size':24})

        
        #t1 = TextArea(self.name, x=self.x, y=self.y)
        t1 = TextArea(self.name, y=5, text_args=text_args)
        self.add(t1)

        self.align = ('center', 'center')
        self.rearrange(keep_dimensions=True)
        t = t1.content
        #print "text: %s dimensions: %s, %s" % (t.text, t.area.w, t.area.h)
        #self.debug()



class Toggle(Area):
    """
    Toggle defines a default action that changes between one option and another
    """
    def __init__(self, name, on, off, default=False, ttype="text", **kwargs):
        #initialize area first
        Area.__init__(self, name, **kwargs)

        self.align = ('center', 'center')
        self.clickable = True
        self.color = kwargs.get('color', (.5,.5,.5,1))
        self.border = 5

        #override default toggle action with custom behavior:
        self.action = kwargs.get('action', self.toggle)

        self.on_action = kwargs.get('on_action', None)
        self.off_action = kwargs.get('off_action', None)

        #default is off
        self.state = default
        if ttype == "text":
            self.text_args = kwargs.get('text_args', {'color':(0,0,0,255), 'font_size':24})
            self.off = TextArea(off, text_args=self.text_args)
            self.on = TextArea(on, text_args=self.text_args)
            if self.state:
                #on, check if off is longer first
                if len(off) > len(on):
                    self.add(self.off)
                    self.rearrange()
                    self.remove(self.off)
            else:
                #off, check if on is longer first
                if len(on) > len(off):
                    self.add(self.on)
                    self.rearrange()
                    self.remove(self.on)
                    
        else:
            #anything else should be passed in
            self.on = on
            self.off = off

        if self.state:
            self.add(self.on)
            self.rearrange(keep_dimensions=True)
        else:
            self.add(self.off)
            self.rearrange(keep_dimensions=True)

        #self.debug()
        #self.rearrange(keep_dimensions=True)

    def toggle(self, gx=0, gy=0, button=None, modifiers=None, debug=False):
        """
        toggle between calibration sound playing and not playing
        """
        if self.state:
            if debug:
                print "Toggle Off"
            self.deselect()
            if self.off_action:
                #self.off_action(gx, gy, button, modifiers)
                self.off_action(self.name)
        else:
            if debug:
                print "Toggle On"
            self.select()
            if self.on_action:
                #self.on_action(gx, gy, button, modifiers)
                self.on_action(self.name)
            
    def select(self):
        """
        force toggle to be on
        """
        if not self.state:
            self.state = True
            self.remove(self.off)
            self.add(self.on)
            #self.update_layout()
            self.rearrange()
        #otherwise we're already selected
        
    def deselect(self):
        """
        force toggle to be off
        """
        if self.state:
            self.state = False
            self.remove(self.on)
            self.add(self.off)
            #self.update_layout()
            self.rearrange()
        #otherwise already not selected

    #def default_action(self, gx, gy, button, modifiers):
    def default_action(self, gx=0, gy=0, button=None, modifiers=None):
        self.select()
        self.radio.choose(self)
        #self.radio.debug()


class ToggleButton(Toggle):
    """
    special toggle that knows it belongs to a ToggleGroup
    """
    ## #def __init__(self, name, radio, default=False, **kwargs):
    def __init__(self, name, parent, default=False, **kwargs):
        #Toggle.__init__(self, name, default, **kwargs)

        #we have a few things to do in default before calling toggle

        text_args = kwargs.get('text_args', {'color':(0,0,0,255), 'font_size':24})

        on_color = kwargs.get('on_color', (0, .75, 0, 1))
        #on_text = TextArea(name, color=on_color, text_args=text_args)
        #on_text = TextArea(name, text_args=text_args, padding=30, w=100, h=40, align=('center', 'center'), keep_dimensions=True)
        on_text = CenteredButton(name, w=150, h=50, color=on_color, text_args=text_args)
        #on_text = CenteredButton(name,  text_args=text_args)

        #on = Area('on', layout="row", border=2, padding=20, color=on_color, align=('center', 'center'))
        on = Area('on', layout="row", border=2, padding=20, align=('center', 'center'))


        #black = Area('black', w=20, h=20, color=(0,0,0,1))
        #on.add(black)
        on.add(on_text)
        
        off_color = kwargs.get('color', (.75, .75, .75, 1))
        #off_text = Button(name, text_args=text_args)
        #off_text = TextArea(name, color=off_color, text_args=text_args)
        #off_text = TextArea(name, text_args=text_args, padding=30, w=100, h=40, align=('center', 'center'), keep_dimensions=True)
        off_text = CenteredButton(name, w=150, h=50, color=off_color, text_args=text_args)
        #off_text = CenteredButton(name, text_args=text_args)

        #off = Area('off', layout="row", border=2, padding=20, color=off_color, align=('center', 'center'))
        off = Area('off', layout="row", border=2, padding=20, align=('center', 'center'))

        off.add(off_text)

        #on_text.rearrange()
        #off_text.rearrange()

        #on.rearrange()
        #off.rearrange()

        #initialize area
        Toggle.__init__(self, name, on, off, default, ttype='layout', **kwargs)

        #self.debug()
        #self.parent.debug()

        #this should be default right?
        #apparently not
        self.action = self.default_action

        #parent should do, right?
        #who holds us
        #self.radio = radio

        #apparently not set automatically
        self.parent = parent

        
    def default_action(self, gx=0, gy=0, button=None, modifiers=None):
        #print "TOGGLE BUTTON CALLED: %s" % self.name
        self.select()
        #print "parent.choose()"
        self.parent.choose(self)
        #self.parent.debug()

class ToggleGroup(Area):
    """
    ToggleGroup collects a group of Toggles and makes sure that only one of them
    is active at a time
    """
    def __init__(self, name, options, default=None, **kwargs):
        """
        options should be a list of strings to use as labels
        for the radio buttons
        """
        Area.__init__(self, name, **kwargs)
        self.configure(name, options, default, **kwargs)
        
    def configure(self, name, options, default=None, **kwargs):
        """
        set up the toggle group to look the way you want
        """
        self.options = options
        self.selection = None

        self.layout = kwargs.get('layout', 'column')
        
        text_args = kwargs.get('text_args', {'color':(0,0,0,255), 'font_size':20})
        text = TextArea(name, text_args=text_args)
        self.add(text)
        
        for n in self.options:
            if default and default == n:
                #b = ToggleGroupToggle(n, self, default=True, color=self.color)
                b = ToggleButton(n, self, default=True, color=self.color)
                self.selection = b
            else:
                #b = ToggleGroupToggle(n, self, color=self.color)
                b = ToggleButton(n, self, color=self.color)
            self.add(b)


    def choose(self, button):
        if self.selection is not None:
            if self.selection != button:
                self.selection.deselect()

        button.select()
        self.selection = button

    def clear(self):
        if self.selection is not None:
            self.selection.deselect()
            self.selection = None

    def lock(self, color=None):
        """
        change all items in radio to not be clickable
        """
        for i in self.items:
            i.clickable = False
            if color:
                i.color = color

    def unlock(self):
        for i in self.items:
            i.clickable = True


class CheckBox(Toggle):
    """
    Toggle defines a default action that changes between one option and another
    """
    def __init__(self, name, default=False, **kwargs):
        color = kwargs.get('color', (1, 1, 1, 1))
        text_args = kwargs.get('text_args', {'color':(0,0,0,255), 'font_size':14})
        on_text = TextArea(name, text_args=text_args)
        black = Area('black', w=20, h=20, color=(0,0,0,1))
        on = Area('on', layout="row", border=2, padding=20, color=color, align=('center', 'center'))
        on.add(black)
        on.add(on_text)
        
        off_text = TextArea(name, text_args=text_args)
        white = Area('white', w=20, h=20, color=(1,1,1,1))
        off = Area('off', layout="row", border=2, padding=20, color=color, align=('center', 'center'))
        off.add(white)
        off.add(off_text)

        on.rearrange()
        off.rearrange()
        
        #initialize area
        Toggle.__init__(self, name, on, off, default, ttype='layout', **kwargs)
    

class RadioToggle(CheckBox):
    """
    Toggle defines a default action that changes between one option and another
    """
    def __init__(self, name, radio, default=False, **kwargs):
        CheckBox.__init__(self, name, default, **kwargs)

        #we have a few things to do in default before calling toggle
        self.action = self.default_action

        #who holds us
        self.radio = radio
        
    #def default_action(self, gx, gy, button, modifiers):
    def default_action(self, gx=0, gy=0, button=None, modifiers=None):
        self.select()
        self.radio.choose(self)
        #self.radio.debug()
        
class Radio(ToggleGroup):
    """
    Radio collects a group of RadioToggles and makes sure that only one of them
    is active at a time
    """
    def __init__(self, name, options, default=None, **kwargs):
        """
        options should be a list of strings to use as labels
        for the radio buttons
        """
        ToggleGroup.__init__(self, name, options, default, **kwargs)

    def configure(self, name, options, default=None, **kwargs):
        """
        set up the toggle group to look the way you want
        """
        self.options = options
        self.selection = None

        self.layout = kwargs.get('layout', 'column')
        
        text_args = kwargs.get('text_args', {'color':(0,0,0,255), 'font_size':20})
        text = TextArea(name, text_args=text_args)
        self.add(text)
        
        for n in self.options:
            if default and default == n:
                b = RadioToggle(n, self, default=True, color=self.color)
                self.selection = b
            else:
                b = RadioToggle(n, self, color=self.color)
            self.add(b)



class MultiColumnRadio(Radio):
    """
    For longer lists of options for a radio, it can help to split the list into multiple columns
    """
    def __init__(self, name, options, default=None, columns=2, **kwargs):
        """
        """
        Area.__init__(self, name, **kwargs)
        self.options = options
        self.selection = None

        self.layout = kwargs.get('layout', 'column')

        text_args = kwargs.get('text_args', {'color':(0,0,0,255), 'font_size':20})
        text = TextArea(name, text_args=text_args)
        self.add(text)


        column_len = len(self.options) / columns
        self.columns = Area('columns', layout='row', **kwargs)        
        for i in range(1, columns+1):
            col_name = 'column%s' % i
            cur_column = Area(col_name, layout='column', **kwargs)        
            
            start = (i-1) * column_len
            end = i * column_len
            if i == columns:
                #last one, want to make sure we get any extras
                sub_options = self.options[start:]
            else:
                sub_options = self.options[start:end]
                
        
            for n in sub_options:
                if default and default == n:
                    b = RadioToggle(n, self, default=True, color=self.color, text_args=text_args)
                    self.selection = b
                else:
                    b = RadioToggle(n, self, color=self.color, text_args=text_args)
                cur_column.add(b)
            self.columns.add(cur_column)
        self.add(self.columns)
        
class Message(Area):
    """
    No buttons, just put text in a box
    """
    def __init__(self, lines=[], text='', name='message', **kwargs):
        #initialize area first
        Area.__init__(self, name, **kwargs)

        self.bg = kwargs.get('bg', (.75, .75, .75, 1))

        self.background = Area('background', layout="column",
                               align=("center", "center"), color=self.bg,
                               padding=10, border=10)

        if lines:
            for l in lines:
                t = TextArea(l, text_args={'color':(0,0,0,255), 'font_size':20})
                self.background.add(t)
        elif text:
            t = TextArea(text, text_args={'color':(0,0,0,255), 'font_size':20})
            self.background.add(t)
        else:
            t = TextArea(name, text_args={'color':(0,0,0,255), 'font_size':20})
            self.background.add(t)

        self.add(self.background)
        self.rearrange()


class LeftMessage(Area):
    """
    left aligned message
    (whole Area can then be centered
    """
    def __init__(self, lines=[], name='message', **kwargs):
        #initialize area first
        Area.__init__(self, name, **kwargs)

        width = kwargs.get('width', 850)
        
        self.bg = kwargs.get('bg', (.75, .75, .75, 1))

        self.background = Area('background', layout="column",
                               align=("center", "left"), color=self.bg,
                               padding=10, border=10)

        #for l in lines:
        for line in lines:
            m = TextArea(name=line, text_args={'color':(0,0,0,255), 'multiline':False, 'font_size':20} )
            if m.content.w > width:
                #print m.content.w
                m = TextArea(name=line, text_args={'color':(0,0,0,255), 'multiline':True, 'font_size':20, 'width':width} )
            else:
                #print m.content.w
                pass
            m.rearrange()
            #texta.add(m)
            self.background.add(m)

            #t = TextArea(l, text_args={'color':(0,0,0,255), 'font_size':20})
            #self.background.add(t)

        self.add(self.background)
        self.rearrange()



class OKMessage(Message):
    """
    text, plus a button to continue
    """
    def __init__(self, action, lines=[], name="message", **kwargs):
        #initialize area first
        Message.__init__(self, lines, name, **kwargs)
        button = Button('Ok', action=action)
        self.background.add(button)
        self.background.rearrange()


        
class Dialog(Area):
    def __init__(self, text, action, cancel_action=None, default='', **kwargs):
        Area.__init__(self, 'dialog', **kwargs)

        self.response = ''
        self.callback = action

        self.bg = (.75, .75, .75, 1)

        background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)

        t = TextArea(text, text_args={'color':(0,0,0,255), 'font_size':20})
        background.add(t)

        input_area = Area('input', color=(1, 1, 1, 1), border=3)
        self.field = SingleLineTextInput(default, x=0, y=0, w=300,
                                         #color=(.5, .5, .5, 1),
                                         #black text
                                         color=(0, 0, 0, 255),
                                         action=self.set_response,
                                         input_args={'font_size':20})
        input_area.add(self.field)
        background.add(input_area)

        row = Area('row', padding=10, color=self.bg)
        if cancel_action:
            cancel_b = Button('Cancel', x=0, y=0, w=200, h=50,
                              action=cancel_action, color=(.5, .5, .5, 1))
            row.add(cancel_b)

        accept_b = Button('Ok', x=0, y=0, w=200, h=50,
                          action=self.set_response, color=(.5, .5, .5, 1))
        row.add(accept_b)
        background.add(row)

        self.add(background)

        self.rearrange(keep_dimensions=True)

        #can't do this until the field has a root!
        #self.field.set_focus()
        #self.field.select_all()

        #self.debug()

    ## def on_key_press(self, symbol, modifiers):
    ##     from pyglet.window import key

    ##     #I think the aim behind this is to cycle between different
    ##     #inputs if more than one is on the screen
    ##     #that doesn't happen often
    ##     #and I'm not sure that this works even if it does happen
    ##     #
    ##     #there may be some cases where it is good to get rid of any
    ##     #"ENTER" characters (single line text inputs)
    ##     #but that should be in a configuration, not here.
    ##     #print symbol, key.ENTER
    ##     if symbol == key.ENTER:
    ##         #print "ENTER pressed"
    ##         self.set_response()
            
    def set_response(self, gx=0, gy=0, button=None, modifiers=None):
        self.response = self.field.text
        self.callback(self.response)

class WideDialog(Area):
    def __init__(self, text, action, cancel_action=None, default='', debug=None, **kwargs):
        Area.__init__(self, 'dialog', **kwargs)

        self.response = ''
        self.callback = action

        self.bg = (.75, .75, .75, 1)

        background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)

        t = TextArea(text, text_args={'color':(0,0,0,255), 'font_size':20})
        background.add(t)

        input_area = Area('input', color=(1, 1, 1, 1), border=3)
        self.field = SingleLineTextInput(default, x=0, y=0, w=600,
                                         #color=(.5, .5, .5, 1),
                                         color=(0, 0, 0, 255),
                                         input_args={'font_size':20})
        input_area.add(self.field)
        background.add(input_area)

        row = Area('row', padding=10, color=self.bg)
        if cancel_action:
            cancel_b = Button('Cancel', x=0, y=0, w=200, h=50,
                              action=cancel_action, color=(.5, .5, .5, 1))
            row.add(cancel_b)

        accept_b = Button('Ok', x=0, y=0, w=200, h=50,
                          action=self.set_response, color=(.5, .5, .5, 1))
        row.add(accept_b)
        background.add(row)

        self.add(background)

        self.rearrange(keep_dimensions=True)
            
    def set_response(self, gx=0, gy=0, button=None, modifiers=None):
        self.response = self.field.text
        self.callback(self.response)


class WideDelayDialog(Area):
    def __init__(self, text, action, cancel_action=None, default='', debug=None, **kwargs):
        Area.__init__(self, 'dialog', **kwargs)

        self.response = ''
        self.callback = action
        self.debug = debug

        self.bg = (.75, .75, .75, 1)

        self.background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)

        t = TextArea(text, text_args={'color':(0,0,0,255), 'font_size':20})
        self.background.add(t)

        input_area = Area('input', color=(1, 1, 1, 1), border=3)
        self.field = SingleLineTextInput(default, x=0, y=0, w=600,
                                         #color=(.5, .5, .5, 1),
                                         color=(0, 0, 0, 255),
                                         input_args={'font_size':20})
        input_area.add(self.field)
        self.background.add(input_area)

        self.row = Area('row', padding=10, color=self.bg)
        if cancel_action:
            cancel_b = Button('Cancel', x=0, y=0, w=200, h=50,
                              action=cancel_action, color=(.5, .5, .5, 1))
            self.row.add(cancel_b)

        accept_b = Button('Ok', x=0, y=0, w=200, h=50,
                          action=self.set_response, color=(.5, .5, .5, 1))
        self.row.add(accept_b)
        self.background.add(self.row)

        self.add(self.background)

        self.rearrange(keep_dimensions=True)

        self.background.remove(self.row)

        if self.debug:
            self.debug.write("%s: WideDialog layout complete. Button removed\n" % (datetime.datetime.now()))
        
        pyglet.clock.schedule_once(self.show_button, 5)

        #can't do this until the field has a root!
        #self.field.set_focus()
        #self.field.select_all()

        #self.debug()

    def show_button(self, dt=0):
        if self.debug:
            self.debug.write("%s: WideDialog adding button back in\n" % (datetime.datetime.now()))
        
        self.background.add(self.row)

    def set_response(self, gx=0, gy=0, button=None, modifiers=None):
        if self.debug:
            self.debug.write("%s: WideDialog setting response: %s\n" % (datetime.datetime.now(), self.field.text))
        
        self.response = self.field.text
        self.callback(self.response)

class DelayDialog(Dialog):
    """
    only show 'ok' button after show_button is called
    """
    def __init__(self, text, action, default='', **kwargs):
        Area.__init__(self, 'dialog', **kwargs)

        self.response = ''
        self.callback = action

        self.bg = (.75, .75, .75, 1)

        background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)

        t = TextArea(text, text_args={'color':(0,0,0,255), 'font_size':20})
        background.add(t)

        input_area = Area('input', color=(1, 1, 1, 1), border=3)
        self.field = SingleLineTextInput(default, x=0, y=0, w=300,
                                         #color=(.5, .5, .5, 1),
                                         #black text
                                         color=(0, 0, 0, 255),
                                         #action=self.set_response,
                                         input_args={'font_size':20})
        input_area.add(self.field)
        background.add(input_area)

        self.row = Area('row', padding=10, color=self.bg)

        self.accept_b = Button('Ok', x=0, y=0, w=200, h=50,
                          action=self.set_response, color=(.5, .5, .5, 1))
        self.row.add(self.accept_b)
        background.add(self.row)

        self.add(background)

        self.rearrange(keep_dimensions=True)

        #will re-add after show
        self.row.remove(self.accept_b)
        
        #can't do this until the field has a root!
        #self.field.set_focus()
        #self.field.select_all()

        #self.debug()

    def show_button(self, dt=0):
        self.row.add(self.accept_b)

        #this deterimines if pressing return goes on or not:
        #self.field.action = self.set_response

    def set_response(self, gx=0, gy=0, button=None, modifiers=None):
        self.response = self.field.text
        self.callback(self.response)

        
class FreeClassification(object):
    def __init__(self, window, pairs, subject_id, name, next_step, columns=['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L']):
        """
        show an auditory free classification dialog
        """
        #self.screen = RootArea(window)
        #self.screen = RootArea(window, color=(255,255,255,255))
        self.screen = RootArea(window, color=(1,1,1,1))

        self.layer = RootArea(window, color=(1,1,1,1))
        self.name = name
        
        #transparent background
        blank = FlatContent(self.layer)
        self.layer.content = blank
        self.layer.update_layout()
        #self.layer.debug()

        self.next_step = next_step

        grid_size = len(columns)

        #self.screen.debug()
        #generate overall layout dimensions
        #dimensions are relative to window width
        border = 2

        right_w = 210
        pad = 30

        grid_max_w = self.screen.w * .75
        left_w = self.screen.w * .20

        main_h = self.screen.h

        #need to tailor this depending on screen geometry
        #square screens cannot maximize based on screen height
        ## left_w_max = self.screen.w - grid_dimension - right_w - pad
        ## if left_w_max < left_w:
        ##     left_w = left_w_max

        #this prioritizes left margin width:
        new_grid_max = self.screen.w - left_w - right_w - pad
        grid_max_w = new_grid_max
        
        if main_h < grid_max_w:
            grid_dimension = main_h
        else:
            grid_dimension = grid_max_w
        
        drop_w = int(grid_dimension / grid_size)
        button_w = drop_w - (border * 4)

        #add background first, so buttons will be drawn over it
        background = Area('background', w=left_w, h=main_h, color=(1,1,1,1))
        self.screen.add(background)

        #SET UP LOGS:
        output_prefix = 'output'
        if subject_id:
            self.output_dir = "%s/%s" % (output_prefix, subject_id)
            if not os.path.exists(self.output_dir):
                os.makedirs(self.output_dir)
        else:
            print "NO SUBJECT ID SPECIFIED!"
            exit()
        #subject_id = 'demo'
        log_file = os.path.join(output_prefix, subject_id, self.name + '-' + subject_id + '.csv')
        #log = codecs.open(log_file, 'a', encoding='utf-8')
        log = codecs.open(log_file, 'w', encoding='utf-8')
        #add a header
        parts = [ 'time', 'button_id', 'sound_file', 'action' ]
        log.write(','.join(parts) + '\n')

        results_file = os.path.join(output_prefix, subject_id, self.name + '-results-' + subject_id + '.csv')
        results = codecs.open(results_file, 'w', encoding='utf-8')
        #add a header
        parts = [ 'square', 'button_id', 'sound_file' ]
        log.write(','.join(parts) + '\n')

        self.drops = []
        #CREATE GRID
        x = left_w
        #grid = Area('grid', x=x, w=grid_dimension, h=main_h, align=('center', 'center'))
        grid = Area('grid', x=x, w=grid_dimension, h=grid_dimension, align=('center', 'center'))
        #rows are numbered, columns are lettered
        for number in range(grid_size):
            row_name = "row-%s" % number
            row = Area(row_name)
            for letter in columns:
                name = "%s%s" % (letter, number)
                #rather than passing in items that can be dropped on an area
                #pass the areas that can be dropped on to a droppable item...
                #that way it is the only one who needs to check.
                #drop = DropArea(name, w=drop_w, h=drop_w, droppables=self.buttons, log=log)
                drop = DropArea(name, w=drop_w, h=drop_w, log=log)
                self.drops.append(drop)
                row.add(drop)
            grid.add(row)
        grid.rearrange(keep_dimensions=True)
        #self.screen.update_layout()
        self.screen.add(grid)
        #self.screen.debug()

        #print "making buttons"
        container = Area('container', w=left_w, h=main_h, padding=4, border=10, align=('center', 'center'))
        self.buttons = []
        for p in pairs:
            #b = DropButton(l, w=button_w, h=button_w, draggable=True, color=(0,0,0,1),
            #               sound=sounds[count], log=log)
            #print p[1]
            b = DropButton(p[0], w=button_w, h=button_w, draggable=True, droppables=self.drops, color=(0,0,0,1),
                           sound=p[1], log=log)
            container.add(b)
            self.buttons.append(b)

        #container.debug()
        print "arranging buttons"
        # should auto render container here, to get buttons to line up
        container.rearrange(keep_dimensions=True)
        #container.debug()

        print "moving buttons to toplevel"
        # then make the parent of every button be the rootArea (self.screen)
        for b in self.buttons:
            b.home = (b.x, b.y)
            #container.remove(b)
            #self.screen.add(b)
            #window.push_handlers(b)
            self.layer.add(b)

        window.push_handlers(self.layer)

        #CREATE FINISHED DIALOG
        screenname = '%s-%s-screenshot.png' % (self.name, subject_id)
        screenshot = os.path.join(output_prefix, subject_id, screenname)
        x = left_w + grid_dimension + pad - 10
        finished = FinishedDialog(self.screen, self.buttons, grid, results, screenshot, x=x,
                                  w=right_w, h=self.screen.h, next_step=self.next_step, color=(1,1,1,1))

        #going to show it all of the time now
        self.screen.add(finished)
        window.push_handlers(finished) 

        self.screen.update_layout()
        self.layer.update_layout()
        
        #self.screen.debug()
        #self.layer.debug()

    def draw(self, dt=0):
        self.screen.draw()
        self.layer.draw()

class DropArea(Area):
    """
    Example of assigning other types of content to an Area
    it is fine to do this outside of an object,
    just be sure to get the order right:
    1. create the area
    2. create the content with the new area
    3. assign the content to the area
    """
    def __init__(self, name, **kwargs):
        Area.__init__(self, name, **kwargs)
        self.color = (0, 0, 0, 1)
        border = 1

        fill_w = self.w - (border * 2)
        fill_h = self.h - (border * 2)
        
        fill = Area('fill', x=border, y=border, w=fill_w, h=fill_h,
                    color=(1, 1, 1, 1))
        self.add(fill)

        self.log = kwargs.get('log')
        
class DropButton(Area):
    """
    associate a home location with the button
    if not in a DropArea, return to original location
    """
    def __init__(self, name, **kwargs):
        #initialize area first
        Area.__init__(self, name, **kwargs)

        #now set some default sizes if none have been set:
        self.w = kwargs.get('w', 50)
        self.h = kwargs.get('h', 15)

        self.sound_path = kwargs.get('sound', None)
        self.sound_name = os.path.basename(self.sound_path)
        if sys.platform == 'darwin':
            from AppKit import NSSound
            self.player = NSSound.alloc()
            self.player.initWithContentsOfFile_byReference_(self.sound_path, True)
        else:
            self.sound = pyglet.media.StaticSource(pyglet.media.load(self.sound_path))
            #pyglet.media.load(self.sound_path, streaming=False)

            self.player = pyglet.media.Player()
            #self.player = pyglet.media.ManagedSoundPlayer()

            #self.player = Player()

            self.player.eos_action = 'pause'
            self.player.on_eos = self.on_eos
            self.player.queue(self.sound)


            self.player.seek(0)
        #self.player = None
        
        self.log = kwargs.get('log')

        self.clickable = True
        self.color = kwargs.get('color', (1,0,0,1))
        self.default_color = self.color
        self.click_color = (0, .5, 0, 1)
        self.align = ('center', 'center')
        
        #t1 = TextArea(self.name, x=self.x, y=self.y)
        #normally 14 should be fine, but on netbook for ladder, it's too big
        text_args = kwargs.get('text_args', {'color':(255,255,255,255), 'font_size':14})
        #for very tiny screens:
        #text_args = kwargs.get('text_args', {'color':(255,255,255,255), 'font_size':8})
        t1 = TextArea(self.name, text_args=text_args)
        self.add(t1)

        self.rearrange()

        self.home = (0, 0)
        self.dropped_on = None

    def default_action(self, gx=0, gy=0, button=None, modifiers=None):
        pass

    def on_eos(self):
        if sys.platform != 'darwin':
            self.player.seek(0)
        #print "eos"
        #self.player.queue(self.sound)
        
    ## def play(self, dt=0):
    ##     self.player = Player(self.sound_path)
    ##     self.player.start()
        
    def on_mouse_press(self, gx, gy, button, modifiers):
        Area.on_mouse_press(self, gx, gy, button, modifiers)
        if self.down:
            self.color = self.click_color
            self.draw()

            now = datetime.datetime.now()
            now_str = now.strftime("%Y.%m.%d %H:%M:%S")
            parts = [ now_str, self.name, self.sound_name, "play" ]
            self.log.write(','.join(parts) + '\n')

            ## # pyAudio based player:
            ## self.player = Player(self.sound_path)
            ## self.player.start()


            #self.player = pyglet.media.Player()
            #self.player = pyglet.media.ManagedSoundPlayer()


            #self.player.queue(self.sound)
        
            #self.player.seek(0)
            #self.player.dispatch_events()
            self.player.play()


            #pyglet.clock.tick()
            #trying to schedule so that drawing updates happen first:
            #pyglet.clock.schedule_once(self.play, 1)


    def dropped(self, item):
        now = datetime.datetime.now()
        now_str = now.strftime("%Y.%m.%d %H:%M:%S")
        parts = [ now_str, self.name, self.sound_name, "dropped on %s" % item.name ]
        self.log.write(','.join(parts) + '\n')
        #print "%s detected %s" % (self.name, item.name)
        
    def on_mouse_release(self, gx, gy, button, modifiers):
        if self.down:
            #print "%s released!" % self.name
            self.color = self.default_color
            if self.player:
                if sys.platform == 'darwin':
                    self.player.stop()
                    #pyaudio:
                    #self.player.stop()
                else:
                    #pyglet:
                    self.player.pause()
                    if not self.player.source:
                        self.player.queue(self.sound)
                        
                    self.player.seek(0)

            self.update_layout()
            #for d in self.droppables:
            #    d.debug()

        Area.on_mouse_release(self, gx, gy, button, modifiers)
        #see if we should return home
        if not self.dropped_on and self.x != self.home[0] and self.y != self.home[1]:
            self.x = self.home[0]
            self.y = self.home[1]
            self.rearrange()

class FinishedDialog(Area):
    def __init__(self, parent, buttons, grid, results, screenshot, next_step, log_format=None, **kwargs):
        Area.__init__(self, 'finish_dialog', **kwargs)
        self.parent = parent
        self.buttons = buttons
        self.grid = grid
        self.results = results
        self.screenshot = screenshot

        self.next_step = next_step
        self.log_format = log_format
        
        self.align = ('center', 'center')
        #self.bg = (.75, .75, .75, 1)
        self.bg = (1, 1, 1, 1)

        self.background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)

        self.sure = TextArea("Are you sure?", text_args={'color':(0,0,0,255), 'font_size':20})

        self.row = Area('row', padding=10, color=self.bg)
        yes = Button("Yes", w=80, h=50, action=self.move_to_next)
        no = Button("No", w=80, h=50, action=self.clear_check)
        self.row.add(yes)
        self.row.add(no)

        self.message = Area('message', padding=5, color=self.bg, layout="column", align=("center", "center"))
        m1 = TextArea("Please add", text_args={'color':(0,0,0,255), 'font_size':20})
        m2 = TextArea("all items first", text_args={'color':(0,0,0,255), 'font_size':20})
        self.message.add(m1)
        self.message.add(m2)
        self.message.rearrange()
        
        finished = Button("Finished?", w=100, h=50, action=self.check_finished)

        self.background.add(finished)
        self.add(self.background)
        
        #add everything to get the right dimesions
        self.background.add(self.sure)
        self.background.add(self.row)

        #self.rearrange(keep_dimensions=True)
        self.rearrange()
	#self.background.rearrange()

        self.background.remove(self.sure)
        self.background.remove(self.row)

        self.background.add(self.message)
        #self.rearrange(keep_dimensions=True)
        #self.background.rearrange(keep_dimensions=True)
        self.background.rearrange()
        self.background.remove(self.message)

        #add everything to get the right dimesions
        self.background.add(self.sure)
        self.background.add(self.row)

        #self.rearrange(keep_dimensions=True)
        self.background.rearrange()
        self.rearrange()
	#self.background.rearrange()

        self.background.remove(self.sure)
        self.background.remove(self.row)

        self.update_layout()
        
    def clear_check(self, gx=0, gy=0, button=None, modifiers=None):
        #print "clearing confirm buttons"
        if self.background.contains(self.sure):
            self.background.remove(self.sure)
        if self.background.contains(self.row):
            self.background.remove(self.row)
        if self.background.contains(self.message):
            self.background.remove(self.message)

        self.parent.update_layout()
        self.parent.draw()

    def check_dropped(self, dt=0):
        """
        if all buttons have been dropped somewhere
        show the "Finished" button
        """
        all_dropped = True
        for b in self.buttons:
            if not b.dropped_on:
                all_dropped = False
        return all_dropped

    def check_finished(self, gx=0, gy=0, button=None, modifiers=None):
        if self.check_dropped():
            #show finished button
            if not self.background.contains(self.sure):
                self.background.add(self.sure)
            if not self.background.contains(self.row):
                self.background.add(self.row)
            #if not self.screen.contains(finished):
            #    self.screen.add(finished)
        else:
            self.clear_check()
            if not self.background.contains(self.message):
                self.background.add(self.message)
            pyglet.clock.schedule_once(self.clear_check, 5)
            
        self.parent.update_layout()

        #self.debug()
##         if not self.parent.contains(no):
##             self.parent.add(no)

    def move_to_next(self, gx=0, gy=0, button=None, modifiers=None):
        """
        all done with freeclassification. move on.
        """
        if not self.check_dropped():
            self.check_finished()
        else:
            pyglet.image.get_buffer_manager().get_color_buffer().save(self.screenshot)
            for row in self.grid.items:
                for item in row.items:
                    contains = ''
                    wave = ''
                    if item.holding:
                        contains = item.holding.name
                        wave = item.holding.sound_path
                        if self.log_format == "ladder":
                            pieces = item.name.split('-')
                            rung = pieces[1]
                            parts = [ wave, contains, rung ]
                        else:
                            parts = [ item.name, contains, wave ]
                        self.results.write(','.join(parts) + '\n')
                    #print "Square: %s Contains: %s, %s" % (item.name, contains, wave)
            #print "screen captured... logging next"

            #could go elsewhere if not done:
            self.next_step()
            #exit()

