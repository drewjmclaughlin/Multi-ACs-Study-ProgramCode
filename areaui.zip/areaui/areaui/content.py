# ----------------------------------------------------------------------------
# areaui
# Copyright (c) 2010, Charles Brandt
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
# ----------------------------------------------------------------------------
import pyglet
from pyglet.gl import *

class Content(object):
    """
    Content is a generic object for all items that belong to a Node
    Content joins together a Node and a Path with one another

    and provides a common way to display content
    and get properties of content
    """
    def __init__(self, node=None, path=None, **kwargs):
        #refers more to content in area:
        #zoomable? summarizable?
        #similar to image... tiny, small, medium, large?
        self.scalable = kwargs.get('scalable', False)

        #in percent?
        self._scale = kwargs.get('scale', 1.0)

        self.w = kwargs.get('w', 0)
        self.h = kwargs.get('h', 0)

    def scale(self, scale):
        self._scale = scale

    def delete(self):
        """
        way to consistently clean up any memory in use for content items
        """
        del self

class FlatContent(Content):
    """
    FlatContent takes care of
    drawing / generating the right OpenGL commands
    to add to a batch for rendering

    FlatContent uses an Area to know *where* to draw,
    but Content takes care of *what* to draw.
    """
    def __init__(self, area):
        Content.__init__(self, area)
        self.area = area
        #last_batch, used only to see if the batch has changed
        self.batch = area.batch
        self.group = area.group
        self.vertex_list = None

    def has_point(self, x, y):
        """
        check to see if the points fall within our bounds

        if we were a different shape, could do different calculations here
        """
        #return (x >= self.gx and y >= self.gy
        #        and x <= (self.gx + self.w) and y <= (self.gy + self.h))
        return (x >= self.area.gx and y >= self.area.gy
                and x <= (self.area.gx + self.area.w)
                and y <= (self.area.gy + self.area.h))

    def contains(self, area):
        """
        take another area
        and see if it falls in our content area

        it is up to the content to determine what constitutes containment...
        100%
        >50%
        left corner
        etc
        """
        #could just as easily use our local geometry if we have some
        #instead of our area.
        if ( (area.gx >= self.area.gx) and
             (area.gx <= (self.area.gx + self.area.w)) and
             (area.gy >= self.area.gy) and
             (area.gy <= (self.area.gy + self.area.h)) ):
            return True
        else:
            return False
             
    def update(self):
        """
        this makes sure that the content is represented
        in the area's current batch
        """
        #define in subclasses
        pass

    def fit(self, width, height):
        """
        *** see area.resize for this functionality ***
        
        make sure that the content fits within the width and height
        raise an error if this is not possible
        """
        #define in subclasses
        pass

class Text(FlatContent):
    """
    make pyglet's Label conform to Area and Content concepts
    """
    def __init__(self, area, text, **kwargs):
        FlatContent.__init__(self, area)
        self.text = text
        self.previous_text = self.text
        #incase we need to recreate label later:
        self.kwargs = kwargs
        #text color uses range of 0-255
        #always make sure these settings are mirrored in update method below:
        self.label = pyglet.text.Label(self.text, batch=self.area.batch, group=self.area.group, anchor_x='left', anchor_y='bottom', **self.kwargs)
            
    def update(self):
        if self.batch != self.area.batch:
            self.label.delete()
            self.batch = self.area.batch
            self.label = pyglet.text.Label(self.text, batch=self.area.batch, group=self.area.group, anchor_x='left', anchor_y='bottom', **self.kwargs)
        elif self.previous_text != self.text:
            self.label.text = self.text
            self.previous_text = self.text

        self.label.x = self.area.gx
        self.label.y = self.area.gy

        self.w = self.label.content_width

        #height should be determined by chosen font size:
        #this will only get the height for one line
        #does not work if multiline is set to true
        #font = self.label.document.get_font()
        #self.h = font.ascent - font.descent
        #this appears to be equivalent:
        self.h = self.label.content_height

        
        #print "font height: %s" % self.h
        #print "label height: %s" % self.label.content_height



        #self.area.w = self.label.content_width
        #self.area.h = self.label.content_height

class Input(FlatContent):
    """
    make pyglet's Label conform to Area and Content concepts

    Inspired by Simplui's EditableLabel: Copyright (c) 2009 Tristam MacDonald

    colors here should all be byte values (0-255)
    """
    def __init__(self, area, text, h=None, multiline=True, **kwargs):
        FlatContent.__init__(self, area)
        #incase we need to recreate document later:
        self.kwargs = kwargs

        #convert text color to format needed for caret
        text_color = kwargs.get('color', (0, 0, 0, 1) )
        #caret color expects a byte (0-255) values by default
        #but does not need last byte (only first 3)
        #text color (used in IncrementalTextLayout) should be the same color as caret
        #background not in use here
        self.caret_color = []
        for i in range(3):
            #self.color.append(text_color[i] / 255.0)
            #self.caret_color.append(int(self.color[i] * 255))
            if (text_color[i] <= 1) and (text_color[i] > 0):
                print "looks like a float was passed to areaui.content.Input."
                print "value: %s" % text_color[i]
                print "will probably crash. try byte value 0-255 instead"
            self.caret_color.append(text_color[i])

        ## self.color = []
        ## for i in range(4):
        ##     if i > 1:
        ##         print "Warning, Input expects color in byte form (0-255 values), but TextInput widget background expects floats"
        ##     #self.color.append(text_color[i] / 255.0)
        ##     self.color.append(text_color[i])


        ## #maybe they both expect bytes?
        ## self.color = self.caret_color

        ## #document still uses color from kwargs
        ## #caret color seems to be the only one set from any of the above
        ## #reset color in kwargs
        ## self.kwargs['color'] = self.color
        
        #incase we need to recreate layout later:
        self.multiline = multiline

        self.document = pyglet.text.document.UnformattedDocument(text)
        self.document.set_style(0, len(self.document.text), dict(**self.kwargs))

        #height should be determined by chosen font size:
        if h:
            self.area.h = h
        else:
            font = self.document.get_font()
            self.area.h = font.ascent - font.descent
        
        #self.layout = pyglet.text.layout.IncrementalTextLayout(self.document, 1, 1, multiline=False)
        self.layout = pyglet.text.layout.IncrementalTextLayout(self.document, self.area.w, self.area.h, batch=self.area.batch, group=self.area.group, multiline=self.multiline)
        self.caret = pyglet.text.caret.Caret(self.layout, color=self.caret_color)

        self.layout.x = self.area.gx
        self.layout.y = self.area.gy
        #self.area.w = self.layout.width
        #self.area.h = self.layout.height

    def _get_text(self):
        return self.document.text
    def _set_text(self, text):
        self.document.text = text
    text = property(_get_text, _set_text)

    def update(self):
        #print "Doc text: %s" % self.document.text
        if self.batch != self.area.batch:
            self.caret.delete()
            self.layout.delete()
            ### workaround for pyglet issue 408
            self.layout.batch = None
            if self.layout._document:
                    self.layout._document.remove_handlers(self.layout)
            self.layout._document = None
            ### end workaround

            self.batch = self.area.batch
            self.layout = pyglet.text.layout.IncrementalTextLayout(self.document, self.area.w, self.area.h, batch=self.area.batch, group=self.area.group, multiline=self.multiline)
            #self.layout = pyglet.text.layout.IncrementalTextLayout(self.document, self.area.w, self.area.h, batch=self.area.batch, group=self.area.group)
            self.caret = pyglet.text.caret.Caret(self.layout, color=self.caret_color)
            #self.caret = pyglet.text.caret.Caret(self.layout)
            self.caret.visible = False
            
        self.layout.x = self.area.gx
        self.layout.y = self.area.gy
    

class Sprite(FlatContent):
    """
    make pyglet's Sprite work in Area and Content concepts

    This is the parent class for Image and Animation

    *** Do not use directly! *** 
    """
    def __init__(self, area):
        #Image.__init__(self, area)
        FlatContent.__init__(self, area)

        #subclass to define:
        #self.image
        #self.sprite
        #self.kwargs
        
    def update(self):
        if self.batch != self.area.batch:
            self.sprite.delete()
            del self.batch
            self.batch = self.area.batch
            self.sprite = pyglet.sprite.Sprite(self.image, batch=self.area.batch, group=self.area.group, **self.kwargs)
            self.sprite.scale = self._scale

        self.sprite.x = self.area.gx
        self.sprite.y = self.area.gy
        #if self.area.max_w and self.sprite.width < self.area_max_w:
        #    self.area.w = self.sprite.width
        #else:
        #    self.area.resize(self.area.max_w, self.area.max_h)
        #
        #self.area.h = self.sprite.height

        self.w = self.sprite.width
        self.h = self.sprite.height

    def scale(self, scale=None):
        if scale is not None:
            self._scale = scale
        #print "Before: %s w, %s h" % (self.sprite.width, self.sprite.height)
        self.sprite.scale = self._scale
        #print "After: %s w, %s h" % (self.sprite.width, self.sprite.height)
        self.update()
        
    def delete(self):
        """
        way to consistently clean up any memory in use for content items
        """
        #print "deleting content from: %s" % self.area.name
        self.sprite.delete()

        #del self.image_path
        del self.image
        #del self.kwargs
        
        #del self.batch
        del self

class Image(Sprite):
    """
    make pyglet's Sprite work in Area and Content concepts
    """
    def __init__(self, area, image_path, **kwargs):
        Sprite.__init__(self, area, )
        self.image_path = image_path
        self.image = pyglet.image.load(image_path)

        #incase we need to recreate image later:
        #might be able to just move to a new batch instead of recreate?
        self.kwargs = kwargs
        self.sprite = pyglet.sprite.Sprite(self.image, batch=self.area.batch, group=self.area.group, **self.kwargs)

        self.update()
                
class Animation(Sprite):
    """
    make pyglet's Sprite work in Area and Content concepts
    """
    def __init__(self, area, image_path_list, **kwargs):
        #Image.__init__(self, area)
        FlatContent.__init__(self, area)
        image_list = []
        for i in image_path_list:
            img = pyglet.image.load(i)
            image_list.append(img)
        self.image = pyglet.image.Animation.from_image_sequence(image_list, 1)

        #incase we need to recreate image later:
        #might be able to just move to a new batch instead of recreate?
        self.kwargs = kwargs
        self.sprite = pyglet.sprite.Sprite(self.image, batch=self.area.batch, group=self.area.group, **self.kwargs)

        self.update()
        
class Shape(FlatContent):
    """
    responsible for geometric shapes in OpenGL
    """
    def get_colors(self, points=4):
        """
        take an array that describes one color:
        [ r, g, b, a ]
        and expand it to the number of verticies for the shape
        """
        c = []
        for i in range(points):
            c.extend(self.area.color)
        return c
    
class Rectangle(Shape):
    """
    Standard rectangle shape in Open GL
    """
    def update(self):
        if not self.vertex_list or (self.batch != self.area.batch):
            self.batch = self.area.batch
            self.build_vertex_list()
        else:
            self.update_vertex_list()
            
    def get_vertices(self):
        x1 = self.area.gx
        y1 = self.area.gy
        x2 = self.area.gx + self.area.w
        y2 = self.area.gy + self.area.h
        return ( x1, y1,
                 x1, y2,
                 x2, y2,
                 x2, y1,
                 )

    def build_vertex_list(self):
        self.vertex_list = self.batch.add( 4, GL_QUADS, self.area.group,
                                           ('v2f', self.get_vertices()),
                                           ('c4f', self.get_colors()) )

    def update_vertex_list(self):
        self.vertex_list.vertices = self.get_vertices()
        self.vertex_list.colors = self.get_colors()

class Gradient(Rectangle):
    """
    rather than assume a solid color, accept the four colors used for each point
    points are ordered:
    bottom left, upper left, upper right, bottom right
    """
    def __init__(self, area, colors):
        FlatContent.__init__(self, area)
        self.colors = colors
        print len(self.colors)
        
    def get_colors(self, points=4):
        """
        assumes that the color array was passed in on init
        """
        c = []
        for color in self.colors:
            c.extend(color)
        return c
        #return self.colors

class Waveform(FlatContent):
    #http://www.ocf.berkeley.edu/~fricke/projects/waveform/waveform.c
##     source = wave.open('sound.wav')

##     width = source.getsampwidth()

##     total_source_frames = source.getnframes()
##     frame = 0
##     for frame in range(total_source_frames):
##         f1 = source.readframes(1)


##     source.close()
    pass
