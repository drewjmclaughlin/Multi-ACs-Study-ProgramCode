import codecs, re, os

def is_filename(string):
    """
    take a string, and look to see if it is a valid filename
    return type if it is
    """
    sounds = [ '.WAV', '.wav', '.aif', '.AIF' ]
    images = [ '.JPG', '.jpg', '.jpeg', '.TIF', '.tif', '.GIF', '.gif', 
               '.BMP', '.bmp', '.PCX', '.pcx', '.TAR', '.tar', '.PNG', '.png' ]
    movies = [ '.AVI', '.avi', '.mpg', '.MPG', '.mpeg' ]

    root, extension = os.path.splitext(string)
    #print extension
    if extension:
        if extension in sounds:
            #print "SOUND!"
            return "Sound"
        elif extension in images:
            return "Image"
        elif extension in movies:
            return "Movie"
        else:
            return False
    else:
        return False
    

class SSF(list):
    """
    object to assist with reading and writing ssf files
    """
    def __init__(self, path=None, items=[], separator=None,
                 separators=[', ', '\t', '|'], comment='%'):
        self.extend(items)

        #the first separator listed will be used as the default for writing
        self.separators = separators
        if separator is not None:
            if not separator in self.separators:
                self.separators.append(separator)

        self.comment = comment

        if path:
            self.path = path
            self.read()
        else:
            self.path = None

        
        
    #aka load_ssf
    def read(self, path=None, separator=None, separators=None, comment='%'):
        """
        load a value separated file into a list of lists
        each line in the file will correspond to an item in the main, outer list
        each item in a line will correspond to an item in the equivalent inner list

        separator determines how each line is split
        (tab is used if none specified)
        """
        if not separators is None:
            self.separators = separators
        if not separator is None and not separator in self.separators:
            self.separators.append(separator)

        if comment != self.comment:
            self.comment = comment

        if path:
            self.path = path
        if not self.path:
            raise AttributeError, "Path must be specified"
            
        #outer = []
        #print self.separators
        
        #clear our current contents:
        del self[:]

        f = codecs.open(self.path, encoding='utf-8')

        for line in f:
            #remove leading and trailing whitespace (including newline):
            line = line.strip()
            
            if self.comment:
                parts = line.split(self.comment, 1)
                line = parts[0]
            if line:
                parts = [ line ]
                for s in self.separators:
                    new_parts = []
                    for p in parts:
                        p = p.strip()
                        pieces = p.split(s)
                        new_parts.extend(pieces)
                    parts = new_parts
                    #parts = line.split(separator)

                #might always be true now that line is in parts
                if len(parts) >= 1:
                    self.append(parts)

        f.close()
        return self



    
