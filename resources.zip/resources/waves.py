import os, random
import wave
import audioop

def add_waves(s, n, d, sound_level=1.0, noise_level=1.0):
    source = wave.open(s)
    noise = wave.open(n)
    merge = wave.open(d, 'w')

    #find sound length
    source_frames = source.getnframes()
    width = source.getsampwidth()
    rate = source.getframerate()

    seconds = .5
    pad_frames = int(rate * seconds)
    pad_total = pad_frames * 2

    #get noise segment of correct length
    noise_segment_length = pad_total + source_frames
    noise_frames = noise.getnframes()
    start = random.randrange(0, noise_frames-noise_segment_length-10)
    #print "Noise is %s, segment is %s (samples long), starting at: %s" % (noise_frames, noise_segment_length, start)


    noise.setpos(start)

    temp_file = 'output/noise_temp.wav'
    noise_temp = wave.open(temp_file, 'w')
    noise_temp.setsampwidth(width)
    noise_temp.setnchannels(source.getnchannels())
    noise_temp.setframerate(source.getframerate())
    noise_temp.writeframes(noise.readframes(int(noise_segment_length)))
    noise.close()
    noise_temp.close()

    noise_segment = wave.open(temp_file)

    merge.setsampwidth(width)
    merge.setnchannels(source.getnchannels())
    merge.setframerate(source.getframerate())
    #mix with noise
    merge.writeframes(noise_segment.readframes(pad_frames))

    f1 = source.readframes(source_frames)
    f2 = noise_segment.readframes(source_frames)
    f1 = audioop.mul(f1, width, sound_level)
    f2 = audioop.mul(f2, width, noise_level)
    m = audioop.add(f1, f2, width)
    merge.writeframes(m)

    merge.writeframes(noise_segment.readframes(pad_frames))

    merge.close()
    source.close()
    noise_segment.close()
