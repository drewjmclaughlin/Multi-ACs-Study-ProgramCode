import os, codecs, sys, json
from datetime import datetime

import pyglet

from areaui.area import Area, RootArea
from areaui.widgets import TextInput, TextArea, Radio, Button, Message, ImageArea, SingleLineTextInput
#from areaui.sound import Player

class SetupDialog(RootArea):
    """
    common dialog for collecting experiment configuration values
    including subject ID and conditions
    """
    def __init__(self, window, text, callback, cancel_action=None, **kwargs):
        RootArea.__init__(self, window, **kwargs)

        self.response = ''
        self.callback = callback

        self.bg = (.75, .75, .75, 1)

        background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)

        t = TextArea(text, text_args={'color':(0,0,0,255), 'font_size':20})
        background.add(t)

        input_area = Area('input', color=(1, 1, 1, 1), border=3)
        self.field = SingleLineTextInput('User Name', text='', x=0, y=0, w=300,
                                         #color=(128, 128, 128, 255),  #text color
                                         input_args={'font_size':20})
        input_area.add(self.field)
        background.add(input_area)

        #self.condition = Radio('Condition:', ['Native', 'Nonnative'], default="Native", color=self.bg)
        #background.add(self.condition)

        row2 = Area('row2', padding=10, color=self.bg)
        if cancel_action:
            cancel_b = Button('Cancel', x=0, y=0, w=200, h=50,
                              action=cancel_action, color=(.5, .5, .5, 1))
            row2.add(cancel_b)

        accept_b = Button('Ok', x=0, y=0, w=200, h=50,
                          action=self.set_response, color=(.5, .5, .5, 1))
        row2.add(accept_b)
        background.add(row2)

        screen = Area('screen', w=self.w, h=self.h, align=("center", "center"))
        screen.add(background)
        screen.rearrange()

        self.add(screen)

        self.rearrange()

        #can't do this until the field has a root!
        #self.field.set_focus()
        #self.field.select_all()

        #self.debug()

    #def set_response(self, gx, gy, button, modifiers):
    def set_response(self):
        #self.response = [ self.field.text, self.condition.selection.name ] 
        self.response = [ self.field.text ] 
        self.callback(self.response)

class ResumeDialog(RootArea):
    """
    dialog to notify of a resumed session
    make sure user is ready to continue
    """
    def __init__(self, window, lines, callback, **kwargs):
        RootArea.__init__(self, window, **kwargs)

        self.response = ''
        self.callback = callback

        self.bg = (.75, .75, .75, 1)

        background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)


        texta = Area('text_area', layout="column", align=("top", "left"), color=self.bg, padding=10, border=10)
        for line in lines:
            width = 750
            m = TextArea(name=line, text_args={'color':(0,0,0,255), 'multiline':False, 'font_size':16} )
            if m.content.w > width:
                #print m.content.w
                m = TextArea(name=line, text_args={'color':(0,0,0,255), 'multiline':True, 'font_size':16, 'width':750} )
            else:
                #print m.content.w
                pass
            m.rearrange()
            texta.add(m)

        background.add(texta)

        row2 = Area('row2', padding=10, color=self.bg)
        accept_b = Button('Ok', x=0, y=0, w=200, h=50,
                          action=self.set_response, color=(.5, .5, .5, 1))
        row2.add(accept_b)
        background.add(row2)

        screen = Area('screen', w=self.w, h=self.h, align=("center", "center"))
        screen.add(background)
        screen.rearrange()

        self.add(screen)

        self.rearrange()

        #self.debug()

    #def set_response(self, gx, gy, button, modifiers):
    def set_response(self):
        #self.response = [ self.field.text, self.condition.selection.name ]
        self.response = None
        self.callback(self.response)

class BlockWait(RootArea):
    """
    prompt the subject to wait
    calling function takes care of timing
    and calling self.show_button() after enough time waiting has passed
    """
    def __init__(self, window, current, total, **kwargs):
        #kwargs['color'] = (1, 1, 1, 1)
        RootArea.__init__(self, window, **kwargs)
        self.align = ('center', 'center')
        self.layout = "column"
        self.padding = 20

        self.bg = (.75, .75, .75, 1)
        self.background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)

        m = TextArea(name="You have finished block %s out of %s." % (current, total), text_args={'color':(0,0,0,255), 'font_size':20} )
        #m = TextArea(name='You have finished with half of the experiment.')
        self.background.add(m)
        self.wait1 = TextArea(name="Please take a break.", text_args={'color':(0,0,0,255), 'font_size':20} )
        self.wait2 = TextArea(name="You can start the next block in a few minutes.", text_args={'color':(0,0,0,255), 'font_size':20} )
        self.background.add(self.wait1)
        self.background.add(self.wait2)

        self.next_block = TextArea(name='Press the "Continue" button to move on to the next block.', text_args={'color':(0,0,0,255), 'font_size':20} )
        self.background.add(self.next_block)
        
        self.add(self.background)

        #self.rearrange(keep_dimensions=True)
        self.rearrange()

        self.background.remove(self.next_block)
        self.update_layout()

    def show_button(self, dt=0):
        self.background.remove(self.wait1)
        self.background.remove(self.wait2)

        self.background.add(self.next_block)
        #self.background.add(m)
        button = Button("Continue", action=self.action)
        self.background.add(button)

        self.background.rearrange()
        self.rearrange(keep_dimensions=True)

    def exit_action(self, gx=0, gy=0, button=None, modifiers=None):
        #this way the extra parameters passed to an action won't be confusing to exit()
        exit()

class Finished(RootArea):
    """
    standard screen to end the experiment
    """
    def __init__(self, window, **kwargs):
        #kwargs['color'] = (1, 1, 1, 1)
        RootArea.__init__(self, window, **kwargs)
        #self.area.clear()
        self.align = ("center", "center")
        self.layout = "column"

        self.bg = (.75, .75, .75, 1)
        background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)

        m = TextArea(name="You are finished with the experiment.", text_args={'color':(0,0,0,255), 'font_size':20} )
        background.add(m)
        m = TextArea(name='Please exit the booth quietly', text_args={'color':(0,0,0,255), 'font_size':20} )
        background.add(m)
        m = TextArea(name='Thank you for your participation!', text_args={'color':(0,0,0,255), 'font_size':20} )
        background.add(m)

        ## m = TextArea(name="You have finished the experiment.  Thank you!", text_args={'color':(0,0,0,255), 'font_size':20} )
        ## background.add(m)
        ## m = TextArea(name='Please exit the booth quietly', text_args={'color':(0,0,0,255), 'font_size':20} )
        ## background.add(m)

        self.add(background)
        
        # alternative approach
        ## lines = []
        ## lines.append("Experiment finished.  Thank you!")
        ## complete = Message(lines, color=(.5, .5, .5, 1))
        ## self.add(complete)

        self.rearrange()

class Instructions(RootArea):
    """
    pass in instructions as a list of lines
    these are formatted and presented to the user
    one button, continue, enables next action
    """
    def __init__(self, window, lines, **kwargs):
        #kwargs['color'] = (1, 1, 1, 1)
        RootArea.__init__(self, window, **kwargs)
        self.align = ('center', 'center')
        self.layout = "column"
        self.padding = 20

        self.bg = (.75, .75, .75, 1)
        background = Area('background', layout="column", align=("center", "center"), color=self.bg, padding=10, border=10)

        texta = Area('text_area', layout="column", align=("top", "left"), color=self.bg, padding=10, border=10)
        for line in lines:
            width = 750
            m = TextArea(name=line, text_args={'color':(0,0,0,255), 'multiline':False, 'font_size':16} )
            if m.content.w > width:
                #print m.content.w
                m = TextArea(name=line, text_args={'color':(0,0,0,255), 'multiline':True, 'font_size':16, 'width':750} )
            else:
                #print m.content.w
                pass
            m.rearrange()
            texta.add(m)

        background.add(texta)

        #m = ImageArea('resources/scale-1.png')
        #self.add(m)

        #button = Button("CONTINUE", action=self.action)
        #button = Button("Continue", action=self.action, text_args={'color':(0,0,0,255), 'font_size':24})
        button = Button("Next", action=self.action, text_args={'color':(0,0,0,255), 'font_size':24})

        #button.debug()
        #print button.action
        background.add(button)

        self.add(background)

        self.rearrange(keep_dimensions=True)
        #self.debug()


class PlayWaves(object):
    """
    loop through all sounds
    play
    then pause for continue
    log when continue happens (to illustrate logging)
    """
    def __init__(self, window, sounds, subject_id, next_step, position_file, **kwargs):
        self.layout = RootArea(window)

        self.back = next_step
        self.window = window
        
        self.subject_id = subject_id

        self.position_file = position_file

        position = codecs.open(self.position_file, 'r', encoding='utf-8')
        state = json.loads(position.read())
        position.close()

        #keep these around for subsequent position saving
        self.steps = state['steps']
        self.block_count = state['block_count']

        if state.has_key('cur_trial'):
            self.cur_trial = state['cur_trial']
        else:
            self.cur_trial = 0

        self.sounds = sounds
        self.total_sounds = len(self.sounds)

        #apply position, if any, that was loaded from position file:
        self.sounds = self.sounds[self.cur_trial:]


        
        self.blank = RootArea(window)

        self.cue = RootArea(window, align=("center", "center"))
        #plus = TextArea("+", text_args={'color':(0,0,0,255), 'font_size':30})
        plus = TextArea("+", text_args={'color':(255,255,255,255), 'font_size':30})
        self.cue.add(plus)
        self.cue.rearrange()

        self.move_on = RootArea(window, align=("center", "center"))
        continue_b = Button('Continue', x=0, y=0, w=200, h=50,
                            action=self.set_response, color=(.5, .5, .5, 1))
        self.move_on.add(continue_b)
        self.move_on.rearrange()

        if subject_id:
            self.output_dir = "%s/%s" % ('output', subject_id)
            if not os.path.exists(self.output_dir):
                os.makedirs(self.output_dir)
        else:
            print "NO SUBJECT ID SPECIFIED!"
            exit()

        file_name = 'playwave-%s.csv' % ( subject_id )
        log_file = os.path.join(self.output_dir, file_name)
        self.log = codecs.open(log_file, 'a', encoding='utf-8')
        #add a header
        parts = [ 'time', 'sound_file', 'response' ]
        self.log.write(','.join(parts) + '\n')

        #self.layout = self.instructions
        #self.window.push_handlers(self.layout)
        self.start_next()
        
    def start_next(self, gx=0, gy=0, button=None, modifiers=None):
        self.layout = self.blank
        while len(self.window._event_stack):
            self.window.pop_handlers()
        
        if len(self.sounds):
            cur = self.total_sounds - len(self.sounds)
            #could show a result before moving on:
            #self.layout = NextSound(self.window, cur, self.total_sounds, action=self.start_next_block)
            #self.window.push_handlers(self.layout)

            #time to go on to the next sound:
            self.cur_sound = self.sounds.pop(0)
            #often useful to include a correct response with the sound (self.cur_sound[1])
            self.cur_wave = self.cur_sound[0]

            #print self.cur_wave
            pyglet.clock.schedule_once(self.start_trial, .5)

        else:
            #just incase we go straight here from initial call, scheduling avoids recursive call
            pyglet.clock.schedule_once(self.back, .1)
            #self.back()

    def start_trial(self, dt=0, gx=0, gy=0, button=None, modifiers=None):
        self.layout = self.cue
        self.draw()
        pyglet.clock.schedule_once(self.play_current_trial, .5)

    def play_current_trial(self, dt=0):
        self.layout = self.blank

        if sys.platform == 'darwin':
            from AppKit import NSSound
            self.player = NSSound.alloc()
            self.player.initWithContentsOfFile_byReference_(self.cur_wave, True)

            #TODO:
            #no .on_eos functionality here
            
        else:
            self.sound = pyglet.media.StaticSource(pyglet.media.load(self.cur_wave))
            #pyglet.media.load(self.cur_wave, streaming=False)

            self.player = pyglet.media.Player()
            #self.player = pyglet.media.ManagedSoundPlayer()
            #self.player = Player()

            self.player.eos_action = 'pause'
            #self.player.on_eos = self.on_eos
            self.player.on_eos = self.show_dialog
            self.player.queue(self.sound)

        self.player.play()

    def show_dialog(self, dt=0):
        self.layout = self.move_on
        self.window.push_handlers(self.layout)

    def set_response(self, gx=0, gy=0, button=None, modifiers=None):
        #self.response = [ self.field.text, self.condition.selection.name ] 
        self.response = ''

        self.cur_trial += 1

        position = codecs.open(self.position_file, 'w', encoding='utf-8')
        state = {'steps': self.steps, 'block_count':self.block_count, 'cur_trial':self.cur_trial}
        position.write(json.dumps(state))
        position.close()

        now = datetime.now()
        now_str = now.strftime("%Y.%m.%d %H:%M:%S")
        parts = [ now_str, self.cur_wave, response ]
        self.log.write(','.join(parts) + '\n')        

        #maybe clear screen here instead of start_next

        if len(self.sounds):
            self.start_next()
            #self.show_message()
        else:
            pyglet.clock.schedule_once(self.back, .1)
            #self.back()


    def draw(self, dt=0):
        self.layout.draw()

